import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-f87a1703/health", (c) => {
  return c.json({ status: "ok" });
});

// ===== USER ENDPOINTS =====
app.get("/make-server-f87a1703/users/:id", async (c) => {
  const id = c.req.param("id");
  const user = await kv.get(`user:${id}`);
  return c.json(user || null);
});

app.post("/make-server-f87a1703/users", async (c) => {
  const user = await c.req.json();
  await kv.set(`user:${user.id}`, user);
  return c.json(user);
});

app.put("/make-server-f87a1703/users/:id", async (c) => {
  const id = c.req.param("id");
  const user = await c.req.json();
  await kv.set(`user:${id}`, user);
  return c.json(user);
});

// ===== GROUP ENDPOINTS =====
app.get("/make-server-f87a1703/groups", async (c) => {
  const groups = await kv.getByPrefix("group:");
  return c.json(groups || []);
});

app.get("/make-server-f87a1703/groups/:id", async (c) => {
  const id = c.req.param("id");
  const group = await kv.get(`group:${id}`);
  return c.json(group || null);
});

app.post("/make-server-f87a1703/groups", async (c) => {
  const group = await c.req.json();
  await kv.set(`group:${group.id}`, group);
  return c.json(group);
});

app.put("/make-server-f87a1703/groups/:id", async (c) => {
  const id = c.req.param("id");
  const group = await c.req.json();
  await kv.set(`group:${id}`, group);
  return c.json(group);
});

app.delete("/make-server-f87a1703/groups/:id", async (c) => {
  const id = c.req.param("id");
  await kv.del(`group:${id}`);
  return c.json({ success: true });
});

// ===== EVENT ENDPOINTS =====
app.get("/make-server-f87a1703/events", async (c) => {
  const events = await kv.getByPrefix("event:");
  return c.json(events || []);
});

app.get("/make-server-f87a1703/events/:id", async (c) => {
  const id = c.req.param("id");
  const event = await kv.get(`event:${id}`);
  return c.json(event || null);
});

app.post("/make-server-f87a1703/events", async (c) => {
  const event = await c.req.json();
  await kv.set(`event:${event.id}`, event);
  return c.json(event);
});

app.put("/make-server-f87a1703/events/:id", async (c) => {
  const id = c.req.param("id");
  const event = await c.req.json();
  await kv.set(`event:${id}`, event);
  return c.json(event);
});

app.delete("/make-server-f87a1703/events/:id", async (c) => {
  const id = c.req.param("id");
  await kv.del(`event:${id}`);
  return c.json({ success: true });
});

// ===== RSVP ENDPOINTS =====
app.get("/make-server-f87a1703/rsvps", async (c) => {
  const rsvps = await kv.getByPrefix("rsvp:");
  return c.json(rsvps || []);
});

app.get("/make-server-f87a1703/rsvps/:id", async (c) => {
  const id = c.req.param("id");
  const rsvp = await kv.get(`rsvp:${id}`);
  return c.json(rsvp || null);
});

app.post("/make-server-f87a1703/rsvps", async (c) => {
  const rsvp = await c.req.json();
  await kv.set(`rsvp:${rsvp.id}`, rsvp);
  return c.json(rsvp);
});

app.put("/make-server-f87a1703/rsvps/:id", async (c) => {
  const id = c.req.param("id");
  const rsvp = await c.req.json();
  await kv.set(`rsvp:${id}`, rsvp);
  return c.json(rsvp);
});

// ===== MESSAGE ENDPOINTS =====
app.get("/make-server-f87a1703/messages", async (c) => {
  const messages = await kv.getByPrefix("message:");
  return c.json(messages || []);
});

app.post("/make-server-f87a1703/messages", async (c) => {
  const message = await c.req.json();
  await kv.set(`message:${message.id}`, message);
  return c.json(message);
});

// ===== PHOTO ENDPOINTS =====
app.get("/make-server-f87a1703/photos", async (c) => {
  const photos = await kv.getByPrefix("photo:");
  return c.json(photos || []);
});

app.post("/make-server-f87a1703/photos", async (c) => {
  const photo = await c.req.json();
  await kv.set(`photo:${photo.id}`, photo);
  return c.json(photo);
});

app.delete("/make-server-f87a1703/photos/:id", async (c) => {
  const id = c.req.param("id");
  await kv.del(`photo:${id}`);
  return c.json({ success: true });
});

Deno.serve(app.fetch);