import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { User, Plus, Trash2, Edit2, X, Save, UserPlus, CreditCard, Check } from 'lucide-react';
import { storage } from '../utils/storage';
import { Guest, SubscriptionTier } from '../types';
import { AppHeader } from '../components/AppHeader';

export function ProfilePage() {
  const [currentUser, setCurrentUser] = useState(storage.getCurrentUser());
  const [savedGuests, setSavedGuests] = useState<Guest[]>(currentUser?.savedGuests || []);
  const [editingGuest, setEditingGuest] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editRelationship, setEditRelationship] = useState('');
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newGuestName, setNewGuestName] = useState('');
  const [newGuestRelationship, setNewGuestRelationship] = useState('');
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  useEffect(() => {
    const user = storage.getCurrentUser();
    setCurrentUser(user);
    setSavedGuests(user?.savedGuests || []);
  }, []);

  const handleDeleteGuest = (guestId: string) => {
    if (!currentUser) return;
    
    const updatedGuests = savedGuests.filter(g => g.id !== guestId);
    const updatedUser = { ...currentUser, savedGuests: updatedGuests };
    
    storage.saveCurrentUser(updatedUser);
    setSavedGuests(updatedGuests);
    setCurrentUser(updatedUser);
  };

  const handleStartEdit = (guest: Guest) => {
    setEditingGuest(guest.id);
    setEditName(guest.name);
    setEditRelationship(guest.relationship || '');
  };

  const handleSaveEdit = (guestId: string) => {
    if (!currentUser || !editName.trim()) return;
    
    const updatedGuests = savedGuests.map(g => 
      g.id === guestId 
        ? { ...g, name: editName.trim(), relationship: editRelationship.trim() || undefined }
        : g
    );
    
    const updatedUser = { ...currentUser, savedGuests: updatedGuests };
    storage.saveCurrentUser(updatedUser);
    setSavedGuests(updatedGuests);
    setCurrentUser(updatedUser);
    setEditingGuest(null);
    setEditName('');
    setEditRelationship('');
  };

  const handleCancelEdit = () => {
    setEditingGuest(null);
    setEditName('');
    setEditRelationship('');
  };

  const handleAddNewGuest = () => {
    if (!currentUser || !newGuestName.trim()) return;
    
    const newGuest: Guest = {
      id: `saved-${Date.now()}`,
      name: newGuestName.trim(),
      relationship: newGuestRelationship.trim() || undefined
    };
    
    const updatedGuests = [...savedGuests, newGuest];
    const updatedUser = { ...currentUser, savedGuests: updatedGuests };
    
    storage.saveCurrentUser(updatedUser);
    setSavedGuests(updatedGuests);
    setCurrentUser(updatedUser);
    setIsAddingNew(false);
    setNewGuestName('');
    setNewGuestRelationship('');
  };

  const handleCancelAdd = () => {
    setIsAddingNew(false);
    setNewGuestName('');
    setNewGuestRelationship('');
  };

  const handleUpdateSubscription = (tier: SubscriptionTier) => {
    if (!currentUser) return;

    const updatedUser = { ...currentUser, subscription: tier };
    storage.saveCurrentUser(updatedUser);
    setCurrentUser(updatedUser);
    setShowSubscriptionModal(false);
  };

  const getSubscriptionDetails = (tier: SubscriptionTier = 'user') => {
    switch (tier) {
      case 'user':
        return {
          name: 'User',
          price: 'Free',
          priceValue: 0,
          features: [
            'Join groups as a member',
            'Full access to all available groups',
            'RSVP to events',
            'Cannot create groups'
          ]
        };
      case 'standard':
        return {
          name: 'Standard Admin',
          price: '$3.99/month',
          priceValue: 3.99,
          features: [
            'Create up to 5 groups',
            'Up to 30 members per group',
            'Share moderator access with up to 2 members',
            'All User features included'
          ]
        };
      case 'corporate':
        return {
          name: 'Corporate Admin',
          price: '$15.99/month',
          priceValue: 15.99,
          features: [
            'Create up to 10 groups',
            'Up to 200 members per group',
            '2 administrators and 5 moderators',
            'All Standard Admin features included'
          ]
        };
    }
  };

  const currentSubscription = currentUser?.subscription || 'user';
  const subscriptionDetails = getSubscriptionDetails(currentSubscription);

  return (
    <div className="min-h-screen bg-[#F5F1EB]">
      {/* Header */}
      <AppHeader />

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* User Info Section */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold text-[#2D2D2D] mb-4">Account Information</h2>
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium text-[#9B9B9B]">Name</label>
              <p className="text-[#2D2D2D]">{currentUser?.name}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-[#9B9B9B]">Email</label>
              <p className="text-[#2D2D2D]">{currentUser?.email}</p>
            </div>
          </div>
        </div>

        {/* Household Guests Section */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold text-[#2D2D2D]">Household Guests</h2>
              <p className="text-sm text-[#9B9B9B] mt-1">
                Save family members, children, or frequent guests for quick RSVPs
              </p>
            </div>
            <button
              onClick={() => setIsAddingNew(true)}
              className="flex items-center gap-2 px-3 py-1.5 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors text-sm"
            >
              <Plus className="w-4 h-4" />
              Add Guest
            </button>
          </div>

          {/* Add New Guest Form */}
          {isAddingNew && (
            <div className="mb-6 p-4 bg-[#7FA090]/10 border-2 border-[#7FA090]/30 rounded-lg">
              <h3 className="font-semibold text-[#2D2D2D] mb-3">Add New Guest</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-[#2D2D2D] mb-1">
                    Name *
                  </label>
                  <input
                    type="text"
                    value={newGuestName}
                    onChange={(e) => setNewGuestName(e.target.value)}
                    placeholder="Enter guest name"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                    autoFocus
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#2D2D2D] mb-1">
                    Relationship/Notes (optional)
                  </label>
                  <input
                    type="text"
                    value={newGuestRelationship}
                    onChange={(e) => setNewGuestRelationship(e.target.value)}
                    placeholder="e.g., Spouse, Child, Age 8, Friend"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleAddNewGuest}
                    disabled={!newGuestName.trim()}
                    className="flex items-center gap-2 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors disabled:bg-slate-300 disabled:cursor-not-allowed"
                  >
                    <Save className="w-4 h-4" />
                    Save
                  </button>
                  <button
                    onClick={handleCancelAdd}
                    className="flex items-center gap-2 px-4 py-2 border border-stone-300 text-[#2D2D2D] rounded-lg hover:bg-[#F5F1EB] transition-colors"
                  >
                    <X className="w-4 h-4" />
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Guests List */}
          {savedGuests.length === 0 ? (
            <div className="text-center py-12">
              <UserPlus className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <p className="text-[#9B9B9B] mb-2">No saved guests yet</p>
              <p className="text-sm text-[#9B9B9B]">
                Add household guests to quickly include them in event RSVPs
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {savedGuests.map((guest) => (
                <div
                  key={guest.id}
                  className="p-4 bg-[#F5F1EB] rounded-lg border border-stone-200"
                >
                  {editingGuest === guest.id ? (
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-medium text-[#2D2D2D] mb-1">
                          Name *
                        </label>
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                          autoFocus
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#2D2D2D] mb-1">
                          Relationship/Notes (optional)
                        </label>
                        <input
                          type="text"
                          value={editRelationship}
                          onChange={(e) => setEditRelationship(e.target.value)}
                          className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleSaveEdit(guest.id)}
                          disabled={!editName.trim()}
                          className="flex items-center gap-2 px-3 py-1.5 text-sm bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors disabled:bg-slate-300 disabled:cursor-not-allowed"
                        >
                          <Save className="w-4 h-4" />
                          Save
                        </button>
                        <button
                          onClick={handleCancelEdit}
                          className="flex items-center gap-2 px-3 py-1.5 text-sm border border-stone-300 text-[#2D2D2D] rounded-lg hover:bg-[#F5F1EB] transition-colors"
                        >
                          <X className="w-4 h-4" />
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-[#2D2D2D]">{guest.name}</p>
                        {guest.relationship && (
                          <p className="text-sm text-[#9B9B9B]">{guest.relationship}</p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleStartEdit(guest)}
                          className="p-2 text-[#9B9B9B] hover:text-[#7FA090] hover:bg-[#7FA090]/10 rounded-lg transition-colors"
                          title="Edit guest"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Remove ${guest.name} from saved guests?`)) {
                              handleDeleteGuest(guest.id);
                            }
                          }}
                          className="p-2 text-[#9B9B9B] hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete guest"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Subscription Section */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-[#2D2D2D]">Subscription</h2>
            <button
              onClick={() => setShowSubscriptionModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors text-sm whitespace-nowrap"
            >
              <CreditCard className="w-4 h-4" />
              Update
            </button>
          </div>
          <div className="p-4 bg-[#F5F1EB] rounded-lg border border-stone-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-[#2D2D2D]">{subscriptionDetails.name}</p>
                <p className="text-sm text-[#9B9B9B] mt-1">{subscriptionDetails.price}</p>
              </div>
              {currentSubscription !== 'user' && (
                <div className="px-3 py-1 bg-[#7FA090] text-white text-sm rounded-full">
                  Active
                </div>
              )}
            </div>
            <ul className="mt-3 space-y-1">
              {subscriptionDetails.features.map((feature, idx) => (
                <li key={idx} className="text-sm text-[#9B9B9B] flex items-start gap-2">
                  <Check className="w-4 h-4 text-[#7FA090] flex-shrink-0 mt-0.5" />
                  {feature}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </main>

      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-stone-200 p-6 flex items-center justify-between">
              <h3 className="text-2xl font-bold text-[#2D2D2D]">Choose Your Plan</h3>
              <button
                onClick={() => setShowSubscriptionModal(false)}
                className="p-2 text-[#9B9B9B] hover:text-[#2D2D2D] hover:bg-[#F5F1EB] rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* User Plan */}
                <div className={`border-2 rounded-xl p-6 ${currentSubscription === 'user' ? 'border-[#7FA090] bg-[#7FA090]/5' : 'border-stone-200'}`}>
                  <div className="text-center mb-6">
                    <h4 className="text-xl font-bold text-[#2D2D2D] mb-2">User</h4>
                    <div className="mb-4">
                      <span className="text-4xl font-bold text-[#2D2D2D]">Free</span>
                    </div>
                    {currentSubscription === 'user' ? (
                      <div className="px-4 py-2 bg-[#7FA090] text-white rounded-lg font-medium">
                        Current Plan
                      </div>
                    ) : (
                      <button
                        onClick={() => handleUpdateSubscription('user')}
                        className="w-full px-4 py-2 border-2 border-[#7FA090] text-[#7FA090] rounded-lg hover:bg-[#7FA090]/10 transition-colors font-medium"
                      >
                        Downgrade
                      </button>
                    )}
                  </div>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      Join groups as a member
                    </li>
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      Full access to all available groups
                    </li>
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      RSVP to events
                    </li>
                    <li className="flex items-start gap-2 text-sm text-[#9B9B9B]">
                      <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                      Cannot create groups
                    </li>
                  </ul>
                </div>

                {/* Standard Admin Plan */}
                <div className={`border-2 rounded-xl p-6 ${currentSubscription === 'standard' ? 'border-[#7FA090] bg-[#7FA090]/5' : 'border-stone-200'}`}>
                  <div className="text-center mb-6">
                    <h4 className="text-xl font-bold text-[#2D2D2D] mb-2">Standard Admin</h4>
                    <div className="mb-4">
                      <span className="text-4xl font-bold text-[#2D2D2D]">$3.99</span>
                      <span className="text-[#9B9B9B]">/month</span>
                    </div>
                    {currentSubscription === 'standard' ? (
                      <div className="px-4 py-2 bg-[#7FA090] text-white rounded-lg font-medium">
                        Current Plan
                      </div>
                    ) : (
                      <button
                        onClick={() => handleUpdateSubscription('standard')}
                        className="w-full px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity font-medium"
                      >
                        {currentSubscription === 'user' ? 'Upgrade' : 'Downgrade'}
                      </button>
                    )}
                  </div>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      Create up to 5 groups
                    </li>
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      Up to 30 members per group
                    </li>
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      Share moderator access with up to 2 members
                    </li>
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      All User features included
                    </li>
                  </ul>
                </div>

                {/* Corporate Admin Plan */}
                <div className={`border-2 rounded-xl p-6 ${currentSubscription === 'corporate' ? 'border-[#7FA090] bg-[#7FA090]/5' : 'border-stone-200'}`}>
                  <div className="text-center mb-6">
                    <h4 className="text-xl font-bold text-[#2D2D2D] mb-2">Corporate Admin</h4>
                    <div className="mb-4">
                      <span className="text-4xl font-bold text-[#2D2D2D]">$15.99</span>
                      <span className="text-[#9B9B9B]">/month</span>
                    </div>
                    {currentSubscription === 'corporate' ? (
                      <div className="px-4 py-2 bg-[#7FA090] text-white rounded-lg font-medium">
                        Current Plan
                      </div>
                    ) : (
                      <button
                        onClick={() => handleUpdateSubscription('corporate')}
                        className="w-full px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity font-medium"
                      >
                        Upgrade
                      </button>
                    )}
                  </div>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      Create up to 10 groups
                    </li>
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      Up to 200 members per group
                    </li>
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      2 administrators and 5 moderators
                    </li>
                    <li className="flex items-start gap-2 text-sm text-[#2D2D2D]">
                      <Check className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                      All Standard Admin features included
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}