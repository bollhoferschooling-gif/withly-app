import { useNavigate, useParams } from 'react-router';
import { Check, MessageSquare, Calendar } from 'lucide-react';
import { useEffect, useState } from 'react';
import { storage } from '../utils/storage';
import { Event, RSVP } from '../types';

export function RSVPConfirmationPage() {
  const navigate = useNavigate();
  const { eventId } = useParams();
  const [event, setEvent] = useState<Event | null>(null);
  const [attendingCount, setAttendingCount] = useState(0);

  useEffect(() => {
    if (!eventId) return;
    
    const allEvents = storage.getEvents();
    const foundEvent = allEvents.find(e => e.id === eventId);
    setEvent(foundEvent || null);
    
    if (foundEvent) {
      const rsvps = storage.getRSVPs();
      const eventRsvps = rsvps.filter(r => r.eventId === eventId);
      const attending = eventRsvps.filter(r => r.attending === 'yes').length;
      const totalGuests = eventRsvps.reduce((sum, r) => 
        sum + (r.attending === 'yes' ? (r.guests?.length || r.guestCount) : 0), 0
      );
      setAttendingCount(attending + totalGuests);
    }
  }, [eventId]);

  if (!event) {
    return (
      <div className="min-h-screen bg-[#F5F1EB] flex items-center justify-center">
        <p className="text-[#9B9B9B]">Event not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F1EB] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 text-center">
        {/* Success Icon */}
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Check className="w-12 h-12 text-green-600" />
        </div>
        
        {/* Heading */}
        <h1 className="text-3xl font-bold text-[#2D2D2D] mb-2">
          You're all set 🎉
        </h1>
        
        {/* Attendee Count */}
        <p className="text-lg text-[#9B9B9B] mb-8">
          {attendingCount} {attendingCount === 1 ? 'person' : 'people'} attending
        </p>
        
        {/* Event Info */}
        <div className="bg-[#F5F1EB] rounded-lg p-4 mb-8 text-left">
          <h2 className="font-semibold text-[#2D2D2D] mb-1">{event.title}</h2>
          <p className="text-sm text-[#9B9B9B]">
            {new Date(event.date).toLocaleDateString('en-US', { 
              weekday: 'long',
              month: 'long', 
              day: 'numeric',
              year: 'numeric' 
            })}
          </p>
          <p className="text-sm text-[#9B9B9B]">
            {new Date(`2000-01-01T${event.time}`).toLocaleTimeString('en-US', { 
              hour: 'numeric',
              minute: '2-digit'
            })}
          </p>
        </div>
        
        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={() => navigate(`/events/${eventId}`)}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors font-medium"
          >
            <Calendar className="w-5 h-5" />
            View Event
          </button>
          <button
            onClick={() => navigate(`/events/${eventId}?tab=chat`)}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-white border-2 border-slate-300 text-[#2D2D2D] rounded-lg hover:bg-[#F5F1EB] transition-colors font-medium"
          >
            <MessageSquare className="w-5 h-5" />
            Go to Chat
          </button>
        </div>
      </div>
    </div>
  );
}