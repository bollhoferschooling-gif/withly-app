import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router';
import { Calendar, MapPin, Users, Clock } from 'lucide-react';
import { Event, Group } from '../types';
import { storage } from '../utils/storage';
import { AppHeader } from '../components/AppHeader';

export function MyEventsPage() {
  const navigate = useNavigate();
  const [events, setEvents] = useState<Event[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [currentUser] = useState(storage.getCurrentUser());

  useEffect(() => {
    // Check if user is logged in
    if (!currentUser) {
      navigate('/login');
      return;
    }

    loadEvents();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadEvents = () => {
    const allGroups = storage.getGroups();
    const allEvents = storage.getEvents();

    // Get groups the user is a member of
    const userGroups = allGroups.filter(g => g.memberIds.includes(currentUser?.id || ''));
    setGroups(userGroups);

    // Get events from those groups
    const userGroupIds = userGroups.map(g => g.id);
    const userEvents = allEvents.filter(e => userGroupIds.includes(e.groupId));

    // Filter for upcoming events only and sort by date
    const upcomingEvents = userEvents
      .filter(e => new Date(e.date) >= new Date())
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    setEvents(upcomingEvents);
  };

  const getGroupName = (groupId: string) => {
    const group = groups.find(g => g.id === groupId);
    return group?.name || 'Unknown Group';
  };

  const formatEventDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatEventTime = (timeStr: string) => {
    return new Date(`2000-01-01T${timeStr}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-[#F5F1EB]">
      {/* Header */}
      <AppHeader />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#2D2D2D] mb-2">My Upcoming Events</h1>
          <p className="text-[#9B9B9B]">All upcoming events from your groups</p>
        </div>

        {events.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm p-12 text-center">
            <Calendar className="w-16 h-16 text-stone-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-[#2D2D2D] mb-2">No upcoming events</h3>
            <p className="text-[#9B9B9B]">
              You don't have any upcoming events. Check back later or create a new event!
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {events.map((event) => (
              <Link
                key={event.id}
                to={`/events/${event.id}`}
                className="block bg-white rounded-xl shadow-sm hover:shadow-md transition-all overflow-hidden"
              >
                <div className="flex gap-6 p-6">
                  {/* Date Badge */}
                  <div className="flex-shrink-0 w-20 h-20 bg-[#7FA090] rounded-lg flex flex-col items-center justify-center text-white">
                    <div className="text-2xl font-bold">
                      {new Date(event.date).getDate()}
                    </div>
                    <div className="text-xs uppercase">
                      {new Date(event.date).toLocaleDateString('en-US', { month: 'short' })}
                    </div>
                  </div>

                  {/* Event Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold text-[#2D2D2D] mb-1">
                          {event.title}
                        </h3>
                        <p className="text-sm text-[#7FA090] font-medium mb-2">
                          {getGroupName(event.groupId)}
                        </p>
                      </div>
                    </div>

                    <p className="text-[#9B9B9B] mb-4 line-clamp-2">{event.description}</p>

                    <div className="flex flex-wrap gap-4 text-sm text-[#9B9B9B]">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        {formatEventDate(event.date)}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {formatEventTime(event.time)}
                      </div>
                      {event.location && (
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          {event.location}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Event Image */}
                  {event.imageUrl && (
                    <div className="hidden md:block flex-shrink-0">
                      <img
                        src={event.imageUrl}
                        alt={event.title}
                        className="w-32 h-32 object-cover rounded-lg"
                      />
                    </div>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
