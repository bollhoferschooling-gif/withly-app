import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import { Event, Group } from '../types';
import { storage } from '../utils/storage';
import { AppHeader } from '../components/AppHeader';

export function CalendarPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  
  useEffect(() => {
    setEvents(storage.getEvents());
    setGroups(storage.getGroups());
  }, []);
  
  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    
    return { daysInMonth, startingDayOfWeek, year, month };
  };
  
  const { daysInMonth, startingDayOfWeek, year, month } = getDaysInMonth(currentDate);
  
  const getEventsForDate = (day: number) => {
    const dateStr = new Date(year, month, day).toISOString().split('T')[0];
    return events.filter(e => e.date === dateStr);
  };
  
  const selectedDateEvents = selectedDate
    ? events.filter(e => e.date === selectedDate.toISOString().split('T')[0])
    : [];
  
  const previousMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };
  
  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };
  
  const today = new Date();
  const isToday = (day: number) => {
    return (
      day === today.getDate() &&
      month === today.getMonth() &&
      year === today.getFullYear()
    );
  };
  
  const monthName = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  const getGroupName = (groupId: string) => {
    return groups.find(g => g.id === groupId)?.name || 'Unknown Group';
  };
  
  const formatEventTime = (timeStr: string) => {
    return new Date(`2000-01-01T${timeStr}`).toLocaleTimeString('en-US', { 
      hour: 'numeric',
      minute: '2-digit'
    });
  };
  
  return (
    <div className="min-h-screen bg-[#F5F1EB]">
      {/* Header */}
      <AppHeader />
      
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calendar */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-6">
              {/* Calendar Header */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-[#2D2D2D]">{monthName}</h2>
                <div className="flex gap-2">
                  <button
                    onClick={previousMonth}
                    className="p-2 hover:bg-white rounded-lg transition-colors"
                  >
                    <ChevronLeft className="w-5 h-5 text-[#9B9B9B]" />
                  </button>
                  <button
                    onClick={nextMonth}
                    className="p-2 hover:bg-white rounded-lg transition-colors"
                  >
                    <ChevronRight className="w-5 h-5 text-[#9B9B9B]" />
                  </button>
                </div>
              </div>
              
              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-2">
                {/* Weekday Headers */}
                {weekDays.map((day) => (
                  <div
                    key={day}
                    className="text-center text-sm font-semibold text-[#9B9B9B] py-2"
                  >
                    {day}
                  </div>
                ))}
                
                {/* Empty cells before first day */}
                {Array.from({ length: startingDayOfWeek }).map((_, i) => (
                  <div key={`empty-${i}`} className="aspect-square" />
                ))}
                
                {/* Calendar days */}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const day = i + 1;
                  const dayEvents = getEventsForDate(day);
                  const date = new Date(year, month, day);
                  const isSelected = selectedDate?.toDateString() === date.toDateString();
                  
                  return (
                    <button
                      key={day}
                      onClick={() => setSelectedDate(date)}
                      className={`aspect-square p-2 rounded-lg border transition-all ${
                        isToday(day)
                          ? 'border-blue-500 bg-[#7FA090]/50'
                          : isSelected
                          ? 'border-blue-400 bg-[#7FA090]/100'
                          : 'border-stone-200 hover:border-slate-300 hover:bg-[#F5F1EB]'
                      }`}
                    >
                      <div className="h-full flex flex-col">
                        <span
                          className={`text-sm font-medium ${
                            isToday(day)
                              ? 'text-[#7FA090]'
                              : isSelected
                              ? 'text-blue-700'
                              : 'text-[#2D2D2D]'
                          }`}
                        >
                          {day}
                        </span>
                        {dayEvents.length > 0 && (
                          <div className="flex-1 flex items-center justify-center">
                            <div className="flex flex-wrap gap-0.5 justify-center">
                              {dayEvents.slice(0, 3).map((event, idx) => (
                                <div
                                  key={idx}
                                  className="w-1.5 h-1.5 rounded-full bg-[#7FA090]/600"
                                />
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
          
          {/* Event List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-8">
              <h2 className="text-xl font-bold text-[#2D2D2D] mb-4">
                {selectedDate
                  ? selectedDate.toLocaleDateString('en-US', {
                      month: 'long',
                      day: 'numeric',
                    })
                  : 'All Upcoming Events'}
              </h2>
              
              <div className="space-y-3">
                {(selectedDate ? selectedDateEvents : events)
                  .filter(e => new Date(e.date) >= new Date().setHours(0, 0, 0, 0))
                  .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                  .slice(0, 10)
                  .map((event) => (
                    <Link
                      key={event.id}
                      to={`/events/${event.id}`}
                      className="block p-4 border border-stone-200 rounded-lg hover:border-blue-300 hover:bg-[#7FA090]/50 transition-all"
                    >
                      <div className="flex items-start gap-3">
                        <div className="flex-shrink-0 w-12 h-12 bg-[#7FA090]/100 rounded-lg flex flex-col items-center justify-center">
                          <span className="text-xs font-semibold text-[#7FA090]">
                            {new Date(event.date).toLocaleDateString('en-US', { month: 'short' }).toUpperCase()}
                          </span>
                          <span className="text-lg font-bold text-blue-900">
                            {new Date(event.date).getDate()}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-[#2D2D2D] mb-1 truncate">
                            {event.title}
                          </h4>
                          <p className="text-xs text-[#9B9B9B] mb-1">{getGroupName(event.groupId)}</p>
                          <p className="text-xs text-[#9B9B9B]">{formatEventTime(event.time)}</p>
                        </div>
                      </div>
                    </Link>
                  ))}
                
                {(selectedDate ? selectedDateEvents : events).filter(e => 
                  new Date(e.date) >= new Date().setHours(0, 0, 0, 0)
                ).length === 0 && (
                  <div className="text-center py-8 text-[#9B9B9B]">
                    <CalendarIcon className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <p className="text-sm">No events scheduled</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}