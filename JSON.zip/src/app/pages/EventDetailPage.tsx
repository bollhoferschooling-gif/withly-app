import { useState, useEffect, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router';
import { ArrowLeft, Calendar, MapPin, Users, Download, Image as ImageIcon, Plus, Clock, Bell, Edit2, ChevronDown, Trash2 } from 'lucide-react';
import { Event, Group, RSVP } from '../types';
import { storage } from '../utils/storage';
import { RSVPForm } from '../components/RSVPForm';
import { SignupSheetManager } from '../components/SignupSheetManager';
import { PhotoAlbum } from '../components/PhotoAlbum';
import { MessageThread } from '../components/MessageThread';
import { EditEventModal } from '../components/EditEventModal';
import { downloadICalFile, addToGoogleCalendar, addToOutlookCalendar } from '../utils/calendar';
import { AppHeader } from '../components/AppHeader';

export function EventDetailPage() {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const [event, setEvent] = useState<Event | null>(null);
  const [group, setGroup] = useState<Group | null>(null);
  const [rsvps, setRsvps] = useState<RSVP[]>([]);
  const [activeTab, setActiveTab] = useState<'rsvp' | 'signup' | 'photos' | 'chat'>('rsvp');
  const [showCalendarMenu, setShowCalendarMenu] = useState(false);
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const attendeesRef = useRef<HTMLDivElement>(null);
  const currentUser = storage.getCurrentUser();
  
  useEffect(() => {
    loadEventData();
  }, [eventId]);
  
  const loadEventData = () => {
    const events = storage.getEvents();
    const foundEvent = events.find(e => e.id === eventId);
    setEvent(foundEvent || null);
    
    if (foundEvent) {
      const groups = storage.getGroups();
      const foundGroup = groups.find(g => g.id === foundEvent.groupId);
      setGroup(foundGroup || null);
      
      const allRsvps = storage.getRSVPs();
      const eventRsvps = allRsvps.filter(r => r.eventId === eventId);
      setRsvps(eventRsvps);
    }
  };
  
  const formatEventDate = (dateStr: string, timeStr: string) => {
    const date = new Date(dateStr);
    return {
      weekday: date.toLocaleDateString('en-US', { weekday: 'long' }),
      date: date.toLocaleDateString('en-US', { 
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      }),
      time: new Date(`2000-01-01T${timeStr}`).toLocaleTimeString('en-US', { 
        hour: 'numeric',
        minute: '2-digit'
      }),
    };
  };
  
  if (!event || !group) {
    return (
      <div className="min-h-screen bg-[#F5F1EB] flex items-center justify-center">
        <p className="text-[#9B9B9B]">Event not found</p>
      </div>
    );
  }
  
  const attendingCount = rsvps.filter(r => r.attending === 'yes').length;
  const maybeCount = rsvps.filter(r => r.attending === 'maybe').length;
  const notGoingCount = rsvps.filter(r => r.attending === 'no').length;
  const totalMembers = group.memberIds.length;
  const notRespondedCount = totalMembers - rsvps.length;
  const totalGuests = rsvps.reduce((sum, r) => sum + (r.attending === 'yes' ? (r.guests?.length || r.guestCount) : 0), 0);
  
  const calculateDaysUntilDeadline = () => {
    if (!event.rsvpDeadline) return null;
    const deadline = new Date(event.rsvpDeadline);
    const today = new Date();
    const diffTime = deadline.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };
  
  const daysUntilDeadline = calculateDaysUntilDeadline();
  
  const handleViewAttendees = () => {
    attendeesRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };
  
  const handleSendReminder = () => {
    setShowReminderModal(true);
  };
  
  const handleEditEvent = () => {
    setShowEditModal(true);
  };

  const handleUpdateEvent = (updatedEvent: Event) => {
    const allEvents = storage.getEvents();
    const updatedEvents = allEvents.map(e => e.id === updatedEvent.id ? updatedEvent : e);
    storage.saveEvents(updatedEvents);
    setEvent(updatedEvent);
    setShowEditModal(false);
  };

  const handleCancelEvent = () => {
    if (!confirm('Are you sure you want to cancel this event? This action cannot be undone.')) {
      return;
    }

    // Delete the event
    const allEvents = storage.getEvents();
    const updatedEvents = allEvents.filter(e => e.id !== eventId);
    storage.saveEvents(updatedEvents);

    // Navigate back to the group page
    navigate(`/group/${event.groupId}`);
  };
  
  const isOrganizer = currentUser?.id === group.creatorId;
  const eventDate = formatEventDate(event.date, event.time);
  const userRsvp = rsvps.find(r => r.userId === currentUser?.id);
  
  return (
    <div className="min-h-screen bg-[#F5F1EB]">
      {/* Header */}
      <AppHeader />
      
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="space-y-6">
            {/* Event Details Card */}
            <div className="bg-white rounded-xl shadow-sm p-6 space-y-4">
              {/* Admin Actions */}
              {isOrganizer && (
                <div className="flex gap-3 pb-4 border-b">
                  <button
                    onClick={handleEditEvent}
                    className="flex items-center gap-2 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity"
                  >
                    <Edit2 className="w-4 h-4" />
                    Edit Event
                  </button>
                  <button
                    onClick={handleCancelEvent}
                    className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:opacity-90 transition-opacity"
                  >
                    <Trash2 className="w-4 h-4" />
                    Cancel Event
                  </button>
                </div>
              )}

              <div>
                <h2 className="text-lg font-semibold text-[#2D2D2D] mb-2">About</h2>
                <p className="text-[#9B9B9B]">{event.description}</p>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t">
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-[#2D2D2D]">{eventDate.weekday}</p>
                    <p className="text-sm text-[#9B9B9B]">{eventDate.date}</p>
                    <p className="text-sm text-[#9B9B9B]">{eventDate.time}</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-[#2D2D2D]">Location</p>
                    <p className="text-sm text-[#9B9B9B]">{event.location}</p>
                  </div>
                </div>
              </div>
              
              {/* Add to Calendar */}
              <div className="pt-4 border-t">
                <div className="relative">
                  <button
                    onClick={() => setShowCalendarMenu(!showCalendarMenu)}
                    className="flex items-center gap-2 px-4 py-2 bg-white text-[#2D2D2D] rounded-lg hover:bg-slate-200 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    Add to Calendar
                  </button>
                  
                  {showCalendarMenu && (
                    <div className="absolute top-full left-0 mt-2 bg-white border border-stone-200 rounded-lg shadow-lg z-10 min-w-[200px]">
                      <button
                        onClick={() => {
                          addToGoogleCalendar(event, group.name);
                          setShowCalendarMenu(false);
                        }}
                        className="w-full text-left px-4 py-2 hover:bg-[#F5F1EB] text-[#2D2D2D]"
                      >
                        Google Calendar
                      </button>
                      <button
                        onClick={() => {
                          addToOutlookCalendar(event, group.name);
                          setShowCalendarMenu(false);
                        }}
                        className="w-full text-left px-4 py-2 hover:bg-[#F5F1EB] text-[#2D2D2D]"
                      >
                        Outlook Calendar
                      </button>
                      <button
                        onClick={() => {
                          downloadICalFile(event, group.name);
                          setShowCalendarMenu(false);
                        }}
                        className="w-full text-left px-4 py-2 hover:bg-[#F5F1EB] text-[#2D2D2D] border-t"
                      >
                        Download .ics file
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
          {/* Tabs */}
          <div className="bg-white rounded-xl shadow-sm overflow-hidden">
            <div className="border-b border-stone-200">
              <div className="flex">
                <button
                  onClick={() => setActiveTab('rsvp')}
                  className={`flex-1 px-3 py-3 font-medium transition-colors ${
                    activeTab === 'rsvp'
                      ? 'text-[#7FA090] border-b-2 border-[#7FA090]'
                      : 'text-[#9B9B9B] hover:text-[#2D2D2D]'
                  }`}
                >
                  RSVP
                </button>
                <button
                  onClick={() => setActiveTab('signup')}
                  className={`flex-1 px-3 py-3 font-medium transition-colors ${
                    activeTab === 'signup'
                      ? 'text-[#7FA090] border-b-2 border-[#7FA090]'
                      : 'text-[#9B9B9B] hover:text-[#2D2D2D]'
                  }`}
                >
                  Signup Sheets
                </button>
                <button
                  onClick={() => setActiveTab('photos')}
                  className={`flex-1 px-3 py-3 font-medium transition-colors ${
                    activeTab === 'photos'
                      ? 'text-[#7FA090] border-b-2 border-[#7FA090]'
                      : 'text-[#9B9B9B] hover:text-[#2D2D2D]'
                  }`}
                >
                  Photos
                </button>
                <button
                  onClick={() => setActiveTab('chat')}
                  className={`flex-1 px-3 py-3 font-medium transition-colors ${
                    activeTab === 'chat'
                      ? 'text-[#7FA090] border-b-2 border-[#7FA090]'
                      : 'text-[#9B9B9B] hover:text-[#2D2D2D]'
                  }`}
                >
                  Chat
                </button>
              </div>
            </div>

            <div className="p-6">
              {activeTab === 'rsvp' && (
                <RSVPForm
                  event={event}
                  userRsvp={userRsvp}
                  onRsvpSubmit={loadEventData}
                />
              )}

              {activeTab === 'signup' && (
                <SignupSheetManager
                  event={event}
                  group={group}
                  onUpdate={loadEventData}
                />
              )}

              {activeTab === 'photos' && (
                <PhotoAlbum eventId={eventId!} />
              )}

              {activeTab === 'chat' && (
                <MessageThread eventId={eventId} />
              )}
            </div>
          </div>

          {/* Attendees List */}
          <div ref={attendeesRef} className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-bold text-[#2D2D2D] mb-6">Attendees</h2>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
              <div className="flex flex-col items-center justify-center p-3 bg-green-50 rounded-lg">
                <Users className="w-5 h-5 text-green-600 mb-1" />
                <span className="text-2xl font-bold text-green-600">
                  {attendingCount}
                </span>
                <span className="text-xs font-medium text-[#2D2D2D] mt-0.5">Going</span>
              </div>

              {maybeCount > 0 && (
                <div className="flex flex-col items-center justify-center p-3 bg-yellow-50 rounded-lg">
                  <span className="text-2xl font-bold text-yellow-600">
                    {maybeCount}
                  </span>
                  <span className="text-xs font-medium text-[#2D2D2D] mt-0.5">Maybe</span>
                </div>
              )}

              {notGoingCount > 0 && (
                <div className="flex flex-col items-center justify-center p-3 bg-red-50 rounded-lg">
                  <span className="text-2xl font-bold text-red-600">
                    {notGoingCount}
                  </span>
                  <span className="text-xs font-medium text-[#2D2D2D] mt-0.5">Not Going</span>
                </div>
              )}

              {notRespondedCount > 0 && (
                <div className="flex flex-col items-center justify-center p-3 bg-gray-50 rounded-lg">
                  <span className="text-2xl font-bold text-gray-600">
                    {notRespondedCount}
                  </span>
                  <span className="text-xs font-medium text-[#2D2D2D] mt-0.5">Not Responded</span>
                </div>
              )}

              {totalGuests > 0 && (
                <div className="flex flex-col items-center justify-center p-3 bg-[#7FA090]/10 rounded-lg">
                  <span className="text-2xl font-bold text-[#7FA090]">
                    +{totalGuests}
                  </span>
                  <span className="text-xs font-medium text-[#2D2D2D] mt-0.5">Guests</span>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-[#2D2D2D] mb-4">Who's Coming</h3>
                {rsvps.filter(r => r.attending === 'yes').length === 0 ? (
                  <p className="text-sm text-[#9B9B9B] text-center py-4">
                    No RSVPs yet
                  </p>
                ) : (
                  <div className="space-y-3">
                    {rsvps
                      .filter(r => r.attending === 'yes')
                      .map((rsvp) => (
                        <div key={rsvp.id} className="border-b border-stone-100 last:border-0 pb-3 last:pb-0">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-[#2D2D2D]">{rsvp.userName}</span>
                            {rsvp.guestCount > 0 && (
                              <span className="text-xs text-[#9B9B9B]">
                                +{rsvp.guestCount}
                              </span>
                            )}
                          </div>
                          {rsvp.guests && rsvp.guests.length > 0 && (
                            <div className="ml-3 space-y-0.5">
                              {rsvp.guests.map((guest) => (
                                <p key={guest.id} className="text-xs text-[#9B9B9B]">
                                  • {guest.name}
                                </p>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                  </div>
                )}
              </div>

              {maybeCount > 0 && (
                <div>
                  <h3 className="font-semibold text-[#2D2D2D] mb-4">Maybe Attending</h3>
                  <div className="space-y-2">
                    {rsvps
                      .filter(r => r.attending === 'maybe')
                      .map((rsvp) => (
                        <div key={rsvp.id} className="py-2 border-b border-stone-100 last:border-0">
                          <span className="text-sm text-[#2D2D2D]">{rsvp.userName}</span>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Group Chat */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-bold text-[#2D2D2D] mb-4">Event Discussion</h2>
            <MessageThread eventId={eventId} />
          </div>
        </div>
      </main>
      
      {/* Edit Event Modal */}
      {showEditModal && event && (
        <EditEventModal
          event={event}
          onClose={() => setShowEditModal(false)}
          onUpdate={handleUpdateEvent}
        />
      )}

      {/* Send Reminder Modal */}
      {showReminderModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-[#2D2D2D] mb-4">Send Reminder</h3>
            <p className="text-[#9B9B9B] mb-6">
              Send a reminder to members who haven't responded yet? This will notify {notRespondedCount} {notRespondedCount === 1 ? 'person' : 'people'}.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowReminderModal(false)}
                className="flex-1 px-4 py-2 border border-slate-300 text-[#2D2D2D] rounded-lg hover:bg-[#F5F1EB] transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  alert(`Reminder sent to ${notRespondedCount} ${notRespondedCount === 1 ? 'person' : 'people'}`);
                  setShowReminderModal(false);
                }}
                className="flex-1 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors"
              >
                Send Reminder
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}