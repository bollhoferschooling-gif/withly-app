import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router';
import { Plus, Search, Users, Lock, Calendar, User } from 'lucide-react';
import { Group } from '../types';
import { storage, initializeMockData } from '../utils/storage';
import { CreateGroupModal } from '../components/CreateGroupModal';
import { JoinGroupModal } from '../components/JoinGroupModal';
import { CreateEventFlow } from '../components/CreateEventFlow';
import { AppHeader } from '../components/AppHeader';

export function GroupsListPage() {
  const navigate = useNavigate();
  const [groups, setGroups] = useState<Group[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [showCreateEventFlow, setShowCreateEventFlow] = useState(false);
  const [currentUser, setCurrentUser] = useState(storage.getCurrentUser());

  useEffect(() => {
    // Check if user is logged in
    const user = storage.getCurrentUser();
    if (!user) {
      navigate('/login');
      return;
    }

    initializeMockData();
    loadGroups();
  }, [navigate]);
  
  const loadGroups = () => {
    const allGroups = storage.getGroups();
    setGroups(allGroups);
  };
  
  const filteredGroups = groups.filter(group => 
    (!group.isPrivate || group.memberIds.includes(currentUser?.id || '')) &&
    (group.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
     group.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  const handleCreateGroup = (group: Group) => {
    const allGroups = storage.getGroups();
    allGroups.push(group);
    storage.saveGroups(allGroups);
    loadGroups();
    setShowCreateModal(false);
  };
  
  const handleJoinGroup = (code: string) => {
    const allGroups = storage.getGroups();
    const group = allGroups.find(g => g.joinCode === code);
    
    if (group && currentUser) {
      if (!group.memberIds.includes(currentUser.id)) {
        group.memberIds.push(currentUser.id);
        storage.saveGroups(allGroups);
        loadGroups();
      }
      setShowJoinModal(false);
    }
  };
  
  return (
    <div className="min-h-screen bg-[#F5F1EB]">
      {/* Header */}
      <AppHeader />
      
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* Quick Actions */}
        <div className="mb-8 grid grid-cols-2 gap-4 max-w-2xl">
          <button
            onClick={() => setShowCreateEventFlow(true)}
            className="flex flex-col items-center justify-center gap-2 p-4 bg-[#7FA090] text-white rounded-xl shadow-sm hover:shadow-md transition-all hover:opacity-90"
          >
            <Plus className="w-6 h-6" />
            <span className="font-semibold text-sm">Create Event</span>
          </button>
          <Link
            to="/my-events"
            className="flex flex-col items-center justify-center gap-2 p-4 bg-white text-[#2D2D2D] border-2 border-[#7FA090] rounded-xl shadow-sm hover:shadow-md transition-all hover:bg-[#F5F1EB]"
          >
            <Calendar className="w-6 h-6 text-[#7FA090]" />
            <span className="font-semibold text-sm">View My Events</span>
          </Link>
        </div>
        
        {/* Search and Actions */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row gap-4 items-center">
            <div className="relative flex-1 w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-stone-400" />
              <input
                type="text"
                placeholder="Search groups..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
              />
            </div>
            <div className="flex gap-3 w-full sm:w-auto">
              <button
                onClick={() => setShowJoinModal(true)}
                className="flex-1 sm:flex-none px-6 py-3 bg-white text-[#2D2D2D] border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors"
              >
                Join Group
              </button>
              <button
                onClick={() => setShowCreateModal(true)}
                className="flex-1 sm:flex-none flex items-center gap-2 px-6 py-3 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity"
              >
                <Plus className="w-5 h-5" />
                Create Group
              </button>
            </div>
          </div>
        </div>
        
        {/* Groups Grid */}
        {filteredGroups.length === 0 ? (
          <div className="text-center py-16">
            <Users className="w-16 h-16 text-stone-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-[#2D2D2D] mb-2">
              {searchQuery ? 'No groups found' : 'No groups yet'}
            </h3>
            <p className="text-[#9B9B9B] mb-6">
              {searchQuery ? 'Try a different search term' : 'Create your first group to get started'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGroups.map((group) => (
              <Link
                key={group.id}
                to={`/group/${group.id}`}
                className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden"
              >
                {group.imageUrl && (
                  <img
                    src={group.imageUrl}
                    alt={group.name}
                    className="w-full h-48 object-cover"
                  />
                )}
                <div className="p-5">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg font-semibold text-[#2D2D2D]">{group.name}</h3>
                    {group.isPrivate && (
                      <Lock className="w-5 h-5 text-[#9B9B9B] flex-shrink-0" />
                    )}
                  </div>
                  <p className="text-[#9B9B9B] text-sm mb-4 line-clamp-2">
                    {group.description}
                  </p>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-[#9B9B9B]">
                      {group.memberIds.length} {group.memberIds.length === 1 ? 'member' : 'members'}
                    </span>
                    <span className="text-[#7FA090] font-medium">View Group →</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
      
      {/* Modals */}
      {showCreateModal && (
        <CreateGroupModal
          onClose={() => setShowCreateModal(false)}
          onCreate={handleCreateGroup}
        />
      )}
      
      {showJoinModal && (
        <JoinGroupModal
          onClose={() => setShowJoinModal(false)}
          onJoin={handleJoinGroup}
        />
      )}

      {showCreateEventFlow && (
        <CreateEventFlow
          onClose={() => setShowCreateEventFlow(false)}
        />
      )}
    </div>
  );
}