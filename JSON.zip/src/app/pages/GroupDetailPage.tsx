import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router';
import { ArrowLeft, Calendar, Plus, Users, Lock, Copy, Check, UserPlus, FileText, Upload, Image as ImageIcon, Trash2, Edit2, X, Save } from 'lucide-react';
import { Group, Event, GroupFile, Photo } from '../types';
import { storage } from '../utils/storage';
import { CreateEventModal } from '../components/CreateEventModal';
import { MessageThread } from '../components/MessageThread';
import { AppHeader } from '../components/AppHeader';

export function GroupDetailPage() {
  const { groupId } = useParams();
  const [group, setGroup] = useState<Group | null>(null);
  const [events, setEvents] = useState<Event[]>([]);
  const [showCreateEventModal, setShowCreateEventModal] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'events' | 'rules' | 'files' | 'photos'>('events');
  const [newRule, setNewRule] = useState('');
  const [editingRuleIndex, setEditingRuleIndex] = useState<number | null>(null);
  const [editRuleText, setEditRuleText] = useState('');
  const currentUser = storage.getCurrentUser();
  const isAdmin = currentUser?.id === group?.creatorId;
  
  useEffect(() => {
    loadGroupData();
  }, [groupId]);
  
  const loadGroupData = () => {
    const groups = storage.getGroups();
    const foundGroup = groups.find(g => g.id === groupId);
    setGroup(foundGroup || null);
    
    const allEvents = storage.getEvents();
    const groupEvents = allEvents.filter(e => e.groupId === groupId);
    setEvents(groupEvents.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
  };
  
  const handleCreateEvent = (event: Event) => {
    const allEvents = storage.getEvents();
    allEvents.push(event);
    storage.saveEvents(allEvents);
    loadGroupData();
    setShowCreateEventModal(false);
  };
  
  const copyJoinCode = () => {
    if (group?.joinCode) {
      navigator.clipboard.writeText(group.joinCode);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };
  
  const formatEventDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const handleAddRule = () => {
    if (!group || !newRule.trim()) return;

    const updatedGroup = {
      ...group,
      rules: [...(group.rules || []), newRule.trim()]
    };

    const allGroups = storage.getGroups();
    const updatedGroups = allGroups.map(g => g.id === group.id ? updatedGroup : g);
    storage.saveGroups(updatedGroups);
    setGroup(updatedGroup);
    setNewRule('');
  };

  const handleEditRule = (index: number) => {
    if (!group) return;
    setEditingRuleIndex(index);
    setEditRuleText(group.rules?.[index] || '');
  };

  const handleSaveRule = (index: number) => {
    if (!group || !editRuleText.trim()) return;

    const updatedRules = [...(group.rules || [])];
    updatedRules[index] = editRuleText.trim();

    const updatedGroup = { ...group, rules: updatedRules };
    const allGroups = storage.getGroups();
    const updatedGroups = allGroups.map(g => g.id === group.id ? updatedGroup : g);
    storage.saveGroups(updatedGroups);
    setGroup(updatedGroup);
    setEditingRuleIndex(null);
    setEditRuleText('');
  };

  const handleDeleteRule = (index: number) => {
    if (!group) return;

    const updatedRules = (group.rules || []).filter((_, i) => i !== index);
    const updatedGroup = { ...group, rules: updatedRules };
    const allGroups = storage.getGroups();
    const updatedGroups = allGroups.map(g => g.id === group.id ? updatedGroup : g);
    storage.saveGroups(updatedGroups);
    setGroup(updatedGroup);
  };

  const handleUploadFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!group || !e.target.files?.[0]) return;

    const file = e.target.files[0];
    const newFile: GroupFile = {
      id: `file-${Date.now()}`,
      name: file.name,
      url: URL.createObjectURL(file),
      uploadedBy: currentUser?.name || 'Unknown',
      uploadedAt: new Date().toISOString(),
      size: file.size
    };

    const updatedGroup = {
      ...group,
      files: [...(group.files || []), newFile]
    };

    const allGroups = storage.getGroups();
    const updatedGroups = allGroups.map(g => g.id === group.id ? updatedGroup : g);
    storage.saveGroups(updatedGroups);
    setGroup(updatedGroup);
  };

  const handleDeleteFile = (fileId: string) => {
    if (!group) return;

    const updatedFiles = (group.files || []).filter(f => f.id !== fileId);
    const updatedGroup = { ...group, files: updatedFiles };
    const allGroups = storage.getGroups();
    const updatedGroups = allGroups.map(g => g.id === group.id ? updatedGroup : g);
    storage.saveGroups(updatedGroups);
    setGroup(updatedGroup);
  };

  const handleUploadPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!group || !e.target.files?.[0]) return;

    const file = e.target.files[0];
    const newPhoto: Photo = {
      id: `photo-${Date.now()}`,
      eventId: groupId!,
      url: URL.createObjectURL(file),
      uploadedBy: currentUser?.name || 'Unknown',
      createdAt: new Date().toISOString()
    };

    const updatedGroup = {
      ...group,
      photos: [...(group.photos || []), newPhoto]
    };

    const allGroups = storage.getGroups();
    const updatedGroups = allGroups.map(g => g.id === group.id ? updatedGroup : g);
    storage.saveGroups(updatedGroups);
    setGroup(updatedGroup);
  };

  const handleDeletePhoto = (photoId: string) => {
    if (!group) return;

    const updatedPhotos = (group.photos || []).filter(p => p.id !== photoId);
    const updatedGroup = { ...group, photos: updatedPhotos };
    const allGroups = storage.getGroups();
    const updatedGroups = allGroups.map(g => g.id === group.id ? updatedGroup : g);
    storage.saveGroups(updatedGroups);
    setGroup(updatedGroup);
  };
  
  if (!group) {
    return (
      <div className="min-h-screen bg-[#F5F1EB] flex items-center justify-center">
        <p className="text-[#9B9B9B]">Group not found</p>
      </div>
    );
  }
  
  const upcomingEvents = events.filter(e => new Date(e.date) >= new Date());
  const pastEvents = events.filter(e => new Date(e.date) < new Date());
  
  return (
    <div className="min-h-screen bg-[#F5F1EB]">
      {/* Header */}
      <AppHeader />
      
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Events */}
          <div className="lg:col-span-2 space-y-6">
            {/* Group Info Card */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 text-[#9B9B9B]">
                    <Users className="w-5 h-5" />
                    <span>{group.memberIds.length} members</span>
                  </div>
                  <button
                    onClick={() => setShowInviteModal(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity"
                  >
                    <UserPlus className="w-4 h-4" />
                    Invite
                  </button>
                </div>
                {group.isPrivate && group.joinCode && (
                  <button
                    onClick={copyJoinCode}
                    className="flex items-center gap-2 px-4 py-2 bg-white border border-stone-200 text-[#2D2D2D] rounded-lg hover:bg-stone-100 transition-colors"
                  >
                    {copiedCode ? (
                      <>
                        <Check className="w-4 h-4" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        Join Code: {group.joinCode}
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>

            {/* Admin Tabs */}
            {isAdmin && (
              <div className="bg-white rounded-xl shadow-sm">
                <div className="border-b border-stone-200">
                  <div className="flex gap-2 px-6">
                    <button
                      onClick={() => setActiveTab('events')}
                      className={`px-4 py-3 font-medium transition-colors ${
                        activeTab === 'events'
                          ? 'text-[#7FA090] border-b-2 border-[#7FA090]'
                          : 'text-[#9B9B9B] hover:text-[#2D2D2D]'
                      }`}
                    >
                      Events
                    </button>
                    <button
                      onClick={() => setActiveTab('rules')}
                      className={`px-4 py-3 font-medium transition-colors ${
                        activeTab === 'rules'
                          ? 'text-[#7FA090] border-b-2 border-[#7FA090]'
                          : 'text-[#9B9B9B] hover:text-[#2D2D2D]'
                      }`}
                    >
                      Rules
                    </button>
                    <button
                      onClick={() => setActiveTab('files')}
                      className={`px-4 py-3 font-medium transition-colors ${
                        activeTab === 'files'
                          ? 'text-[#7FA090] border-b-2 border-[#7FA090]'
                          : 'text-[#9B9B9B] hover:text-[#2D2D2D]'
                      }`}
                    >
                      Files
                    </button>
                    <button
                      onClick={() => setActiveTab('photos')}
                      className={`px-4 py-3 font-medium transition-colors ${
                        activeTab === 'photos'
                          ? 'text-[#7FA090] border-b-2 border-[#7FA090]'
                          : 'text-[#9B9B9B] hover:text-[#2D2D2D]'
                      }`}
                    >
                      Photos
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            {/* Tab Content */}
            {(!isAdmin || activeTab === 'events') && (
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-[#2D2D2D]">Events</h2>
                  {isAdmin && (
                    <button
                      onClick={() => setShowCreateEventModal(true)}
                      className="flex items-center gap-2 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity"
                    >
                      <Plus className="w-5 h-5" />
                      Create Event
                    </button>
                  )}
                </div>
              
              {/* Upcoming Events */}
              {upcomingEvents.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-lg font-semibold text-[#2D2D2D] mb-4">Upcoming</h3>
                  <div className="space-y-4">
                    {upcomingEvents.map((event) => (
                      <Link
                        key={event.id}
                        to={`/events/${event.id}`}
                        className="flex gap-4 p-4 border border-stone-200 rounded-lg hover:border-[#7FA090] hover:bg-[#7FA090]/5 transition-all"
                      >
                        {event.imageUrl && (
                          <img
                            src={event.imageUrl}
                            alt={event.title}
                            className="w-24 h-24 object-cover rounded-lg flex-shrink-0"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-[#2D2D2D] mb-1">{event.title}</h4>
                          <p className="text-sm text-[#9B9B9B] mb-2 line-clamp-2">{event.description}</p>
                          <div className="flex flex-wrap gap-4 text-sm text-[#9B9B9B]">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {formatEventDate(event.date)} at {event.time}
                            </div>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Past Events */}
              {pastEvents.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-[#2D2D2D] mb-4">Past Events</h3>
                  <div className="space-y-4">
                    {pastEvents.map(event => (
                      <Link
                        key={event.id}
                        to={`/events/${event.id}`}
                        className="flex gap-4 p-4 border border-stone-200 rounded-lg hover:border-slate-300 hover:bg-[#F5F1EB] transition-all opacity-75"
                      >
                        {event.imageUrl && (
                          <img
                            src={event.imageUrl}
                            alt={event.title}
                            className="w-24 h-24 object-cover rounded-lg flex-shrink-0 grayscale"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-[#2D2D2D] mb-1">{event.title}</h4>
                          <p className="text-sm text-[#9B9B9B] mb-2 line-clamp-2">{event.description}</p>
                          <div className="flex flex-wrap gap-4 text-sm text-[#9B9B9B]">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {formatEventDate(event.date)} at {event.time}
                            </div>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
              
              {events.length === 0 && (
                <div className="text-center py-12">
                  <Calendar className="w-12 h-12 text-stone-300 mx-auto mb-3" />
                  <p className="text-[#9B9B9B]">No events yet</p>
                  <p className="text-sm text-[#9B9B9B]">Create your first event to get started</p>
                </div>
              )}
              </div>
            )}

            {/* Rules Section */}
            {(isAdmin && activeTab === 'rules') && (
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-xl font-bold text-[#2D2D2D] mb-6">Group Rules</h2>

                {/* Add New Rule */}
                {isAdmin && (
                  <div className="mb-6 p-4 bg-[#7FA090]/10 border-2 border-[#7FA090]/30 rounded-lg">
                    <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                      Add New Rule
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newRule}
                        onChange={(e) => setNewRule(e.target.value)}
                        placeholder="Enter a group rule..."
                        className="flex-1 px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                        onKeyPress={(e) => e.key === 'Enter' && handleAddRule()}
                      />
                      <button
                        onClick={handleAddRule}
                        disabled={!newRule.trim()}
                        className="px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity disabled:bg-stone-300 disabled:cursor-not-allowed"
                      >
                        <Plus className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                )}

                {/* Rules List */}
                {(!group.rules || group.rules.length === 0) ? (
                  <div className="text-center py-12">
                    <FileText className="w-12 h-12 text-stone-300 mx-auto mb-3" />
                    <p className="text-[#9B9B9B]">No rules yet</p>
                    <p className="text-sm text-[#9B9B9B]">Add rules to help members understand group expectations</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {group.rules?.map((rule, index) => (
                      <div
                        key={index}
                        className="p-4 bg-[#F5F1EB] rounded-lg border border-stone-200"
                      >
                        {editingRuleIndex === index ? (
                          <div className="space-y-3">
                            <input
                              type="text"
                              value={editRuleText}
                              onChange={(e) => setEditRuleText(e.target.value)}
                              className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                              autoFocus
                            />
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleSaveRule(index)}
                                disabled={!editRuleText.trim()}
                                className="flex items-center gap-2 px-3 py-1.5 text-sm bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity disabled:bg-stone-300 disabled:cursor-not-allowed"
                              >
                                <Save className="w-4 h-4" />
                                Save
                              </button>
                              <button
                                onClick={() => {
                                  setEditingRuleIndex(null);
                                  setEditRuleText('');
                                }}
                                className="flex items-center gap-2 px-3 py-1.5 text-sm border border-stone-300 text-[#2D2D2D] rounded-lg hover:bg-stone-50 transition-colors"
                              >
                                <X className="w-4 h-4" />
                                Cancel
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1">
                              <p className="text-[#2D2D2D]">
                                {index + 1}. {rule}
                              </p>
                            </div>
                            {isAdmin && (
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleEditRule(index)}
                                  className="p-2 text-[#9B9B9B] hover:text-[#7FA090] hover:bg-[#7FA090]/10 rounded-lg transition-colors"
                                  title="Edit rule"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => {
                                    if (confirm('Delete this rule?')) {
                                      handleDeleteRule(index);
                                    }
                                  }}
                                  className="p-2 text-[#9B9B9B] hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                  title="Delete rule"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Files Section */}
            {(isAdmin && activeTab === 'files') && (
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-[#2D2D2D]">Files</h2>
                  {isAdmin && (
                    <label className="flex items-center gap-2 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity cursor-pointer">
                      <Upload className="w-5 h-5" />
                      Upload File
                      <input
                        type="file"
                        onChange={handleUploadFile}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>

                {(!group.files || group.files.length === 0) ? (
                  <div className="text-center py-12">
                    <Upload className="w-12 h-12 text-stone-300 mx-auto mb-3" />
                    <p className="text-[#9B9B9B]">No files yet</p>
                    <p className="text-sm text-[#9B9B9B]">Upload documents, forms, or other files to share with the group</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {group.files?.map((file) => (
                      <div
                        key={file.id}
                        className="p-4 bg-[#F5F1EB] rounded-lg border border-stone-200 flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <FileText className="w-10 h-10 text-[#7FA090] flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-[#2D2D2D] truncate">{file.name}</p>
                            <p className="text-sm text-[#9B9B9B]">
                              Uploaded by {file.uploadedBy} • {new Date(file.uploadedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <a
                            href={file.url}
                            download={file.name}
                            className="p-2 text-[#7FA090] hover:bg-[#7FA090]/10 rounded-lg transition-colors"
                            title="Download"
                          >
                            <Upload className="w-5 h-5 rotate-180" />
                          </a>
                          {isAdmin && (
                            <button
                              onClick={() => {
                                if (confirm('Delete this file?')) {
                                  handleDeleteFile(file.id);
                                }
                              }}
                              className="p-2 text-[#9B9B9B] hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              title="Delete"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Photos Section */}
            {(isAdmin && activeTab === 'photos') && (
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-[#2D2D2D]">Photo Album</h2>
                  <label className="flex items-center gap-2 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity cursor-pointer">
                    <ImageIcon className="w-5 h-5" />
                    Upload Photo
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleUploadPhoto}
                      className="hidden"
                    />
                  </label>
                </div>

                {(!group.photos || group.photos.length === 0) ? (
                  <div className="text-center py-12">
                    <ImageIcon className="w-12 h-12 text-stone-300 mx-auto mb-3" />
                    <p className="text-[#9B9B9B]">No photos yet</p>
                    <p className="text-sm text-[#9B9B9B]">Share photos with the group</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {group.photos?.map((photo) => (
                      <div key={photo.id} className="relative group/photo">
                        <img
                          src={photo.url}
                          alt={photo.caption || 'Group photo'}
                          className="w-full aspect-square object-cover rounded-lg"
                        />
                        {isAdmin && (
                          <button
                            onClick={() => {
                              if (confirm('Delete this photo?')) {
                                handleDeletePhoto(photo.id);
                              }
                            }}
                            className="absolute top-2 right-2 p-2 bg-red-600 text-white rounded-lg opacity-0 group-hover/photo:opacity-100 transition-opacity"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                        <div className="mt-2">
                          <p className="text-xs text-[#9B9B9B]">
                            By {photo.uploadedBy} • {new Date(photo.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
          
          {/* Right Column - Group Thread */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-8">
              <h2 className="text-xl font-bold text-[#2D2D2D] mb-4">Group Chat</h2>
              <MessageThread groupId={groupId} />
            </div>
          </div>
        </div>
      </main>
      
      {/* Create Event Modal */}
      {showCreateEventModal && (
        <CreateEventModal
          groupId={groupId!}
          onClose={() => setShowCreateEventModal(false)}
          onCreate={handleCreateEvent}
        />
      )}

      {/* Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-[#2D2D2D]">Invite Members</h2>
              <button
                onClick={() => setShowInviteModal(false)}
                className="text-[#9B9B9B] hover:text-[#2D2D2D]"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              {group?.isPrivate && group?.joinCode ? (
                <>
                  <div>
                    <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                      Join Code
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={group.joinCode}
                        readOnly
                        className="flex-1 px-3 py-2 bg-[#F5F1EB] border border-stone-200 rounded-lg text-[#2D2D2D]"
                      />
                      <button
                        onClick={copyJoinCode}
                        className="px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity"
                      >
                        {copiedCode ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                      </button>
                    </div>
                    <p className="text-sm text-[#9B9B9B] mt-2">
                      Share this code with people you want to invite to the group
                    </p>
                  </div>
                </>
              ) : (
                <div>
                  <p className="text-[#9B9B9B]">
                    This is a public group. Anyone can find and join it from the groups list.
                  </p>
                </div>
              )}

              <div className="pt-4">
                <button
                  onClick={() => setShowInviteModal(false)}
                  className="w-full px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}