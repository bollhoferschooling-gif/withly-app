import { createBrowserRouter } from "react-router";
import { LoginPage } from "./pages/LoginPage";
import { GroupsListPage } from "./pages/GroupsListPage";
import { MyEventsPage } from "./pages/MyEventsPage";
import { GroupDetailPage } from "./pages/GroupDetailPage";
import { EventDetailPage } from "./pages/EventDetailPage";
import { CalendarPage } from "./pages/CalendarPage";
import { RSVPConfirmationPage } from "./pages/RSVPConfirmationPage";
import { ProfilePage } from "./pages/ProfilePage";

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/",
    children: [
      { index: true, Component: GroupsListPage },
      { path: "my-events", Component: MyEventsPage },
      { path: "group/:groupId", Component: GroupDetailPage },
      { path: "events/:eventId", Component: EventDetailPage },
      { path: "events/:eventId/rsvp-confirmed", Component: RSVPConfirmationPage },
      { path: "calendar", Component: CalendarPage },
      { path: "profile", Component: ProfilePage },
    ],
  },
]);