import { Event } from '../types';

export const generateICalFile = (event: Event, groupName: string) => {
  const startDate = new Date(`${event.date}T${event.time}`);
  const endDate = new Date(startDate.getTime() + 2 * 60 * 60 * 1000); // 2 hours duration
  
  const formatDate = (date: Date) => {
    return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  };
  
  const ical = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Group Chat//Event//EN
BEGIN:VEVENT
UID:${event.id}@groupchat.app
DTSTAMP:${formatDate(new Date())}
DTSTART:${formatDate(startDate)}
DTEND:${formatDate(endDate)}
SUMMARY:${event.title}
DESCRIPTION:${event.description}\\n\\nGroup: ${groupName}
LOCATION:${event.location}
END:VEVENT
END:VCALENDAR`;
  
  return ical;
};

export const downloadICalFile = (event: Event, groupName: string) => {
  const ical = generateICalFile(event, groupName);
  const blob = new Blob([ical], { type: 'text/calendar' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${event.title.replace(/\s+/g, '_')}.ics`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export const addToGoogleCalendar = (event: Event, groupName: string) => {
  const startDate = new Date(`${event.date}T${event.time}`);
  const endDate = new Date(startDate.getTime() + 2 * 60 * 60 * 1000);
  
  const formatGoogleDate = (date: Date) => {
    return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  };
  
  const params = new URLSearchParams({
    action: 'TEMPLATE',
    text: event.title,
    details: `${event.description}\n\nGroup: ${groupName}`,
    location: event.location,
    dates: `${formatGoogleDate(startDate)}/${formatGoogleDate(endDate)}`,
  });
  
  window.open(`https://calendar.google.com/calendar/render?${params.toString()}`, '_blank');
};

export const addToOutlookCalendar = (event: Event, groupName: string) => {
  const startDate = new Date(`${event.date}T${event.time}`);
  const endDate = new Date(startDate.getTime() + 2 * 60 * 60 * 1000);
  
  const params = new URLSearchParams({
    path: '/calendar/action/compose',
    rru: 'addevent',
    subject: event.title,
    body: `${event.description}\n\nGroup: ${groupName}`,
    location: event.location,
    startdt: startDate.toISOString(),
    enddt: endDate.toISOString(),
  });
  
  window.open(`https://outlook.live.com/calendar/0/deeplink/compose?${params.toString()}`, '_blank');
};
