import { projectId, publicAnonKey } from '/utils/supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-f87a1703`;

async function apiCall(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
      ...options.headers,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`API call failed: ${endpoint}`, errorText);
    throw new Error(`API call failed: ${response.status} ${errorText}`);
  }

  return response.json();
}

// User API
export const userAPI = {
  get: (id: string) => apiCall(`/users/${id}`),
  create: (user: any) => apiCall('/users', { method: 'POST', body: JSON.stringify(user) }),
  update: (id: string, user: any) => apiCall(`/users/${id}`, { method: 'PUT', body: JSON.stringify(user) }),
};

// Group API
export const groupAPI = {
  getAll: () => apiCall('/groups'),
  get: (id: string) => apiCall(`/groups/${id}`),
  create: (group: any) => apiCall('/groups', { method: 'POST', body: JSON.stringify(group) }),
  update: (id: string, group: any) => apiCall(`/groups/${id}`, { method: 'PUT', body: JSON.stringify(group) }),
  delete: (id: string) => apiCall(`/groups/${id}`, { method: 'DELETE' }),
};

// Event API
export const eventAPI = {
  getAll: () => apiCall('/events'),
  get: (id: string) => apiCall(`/events/${id}`),
  create: (event: any) => apiCall('/events', { method: 'POST', body: JSON.stringify(event) }),
  update: (id: string, event: any) => apiCall(`/events/${id}`, { method: 'PUT', body: JSON.stringify(event) }),
  delete: (id: string) => apiCall(`/events/${id}`, { method: 'DELETE' }),
};

// RSVP API
export const rsvpAPI = {
  getAll: () => apiCall('/rsvps'),
  get: (id: string) => apiCall(`/rsvps/${id}`),
  create: (rsvp: any) => apiCall('/rsvps', { method: 'POST', body: JSON.stringify(rsvp) }),
  update: (id: string, rsvp: any) => apiCall(`/rsvps/${id}`, { method: 'PUT', body: JSON.stringify(rsvp) }),
};

// Message API
export const messageAPI = {
  getAll: () => apiCall('/messages'),
  create: (message: any) => apiCall('/messages', { method: 'POST', body: JSON.stringify(message) }),
};

// Photo API
export const photoAPI = {
  getAll: () => apiCall('/photos'),
  create: (photo: any) => apiCall('/photos', { method: 'POST', body: JSON.stringify(photo) }),
  delete: (id: string) => apiCall(`/photos/${id}`, { method: 'DELETE' }),
};
