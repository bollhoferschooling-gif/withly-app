import { Group, Event, RSVP, Message, Photo, User } from '../types';

const STORAGE_KEYS = {
  GROUPS: 'groupchat_groups',
  EVENTS: 'groupchat_events',
  RSVPS: 'groupchat_rsvps',
  MESSAGES: 'groupchat_messages',
  PHOTOS: 'groupchat_photos',
  CURRENT_USER: 'groupchat_current_user',
};

// Storage helpers
export const storage = {
  // Groups
  getGroups: (): Group[] => {
    const data = localStorage.getItem(STORAGE_KEYS.GROUPS);
    return data ? JSON.parse(data) : [];
  },
  saveGroups: (groups: Group[]) => {
    localStorage.setItem(STORAGE_KEYS.GROUPS, JSON.stringify(groups));
  },
  
  // Events
  getEvents: (): Event[] => {
    const data = localStorage.getItem(STORAGE_KEYS.EVENTS);
    return data ? JSON.parse(data) : [];
  },
  saveEvents: (events: Event[]) => {
    localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
  },
  
  // RSVPs
  getRSVPs: (): RSVP[] => {
    const data = localStorage.getItem(STORAGE_KEYS.RSVPS);
    return data ? JSON.parse(data) : [];
  },
  saveRSVPs: (rsvps: RSVP[]) => {
    localStorage.setItem(STORAGE_KEYS.RSVPS, JSON.stringify(rsvps));
  },
  
  // Messages
  getMessages: (): Message[] => {
    const data = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    return data ? JSON.parse(data) : [];
  },
  saveMessages: (messages: Message[]) => {
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
  },
  
  // Photos
  getPhotos: (): Photo[] => {
    const data = localStorage.getItem(STORAGE_KEYS.PHOTOS);
    return data ? JSON.parse(data) : [];
  },
  savePhotos: (photos: Photo[]) => {
    localStorage.setItem(STORAGE_KEYS.PHOTOS, JSON.stringify(photos));
  },
  
  // Current User
  getCurrentUser: (): User | null => {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return data ? JSON.parse(data) : null;
  },
  saveCurrentUser: (user: User) => {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  },
};

// Initialize with mock data if empty
export const initializeMockData = () => {
  const groups = storage.getGroups();
  
  if (groups.length === 0) {
    // Create mock user
    const mockUser: User = {
      id: 'user-1',
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
    };
    storage.saveCurrentUser(mockUser);
    
    // Create mock groups
    const mockGroups: Group[] = [
      {
        id: 'group-1',
        name: 'Book Club Adventures',
        description: 'Monthly meetups to discuss our favorite books and authors',
        isPrivate: false,
        creatorId: 'user-1',
        memberIds: ['user-1', 'user-2', 'user-3', 'user-4'],
        createdAt: new Date('2026-01-15').toISOString(),
        imageUrl: 'https://images.unsplash.com/photo-1669016020285-b2de13e1f0e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY2x1YiUyMG1lZXRpbmclMjBjb2ZmZWV8ZW58MXx8fHwxNzczNzUyMzUwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      },
      {
        id: 'group-2',
        name: 'Family Game Night',
        description: 'Weekly game nights with family and friends',
        isPrivate: true,
        joinCode: 'GAME2026',
        creatorId: 'user-1',
        memberIds: ['user-1', 'user-5', 'user-6'],
        createdAt: new Date('2026-02-01').toISOString(),
        imageUrl: 'https://images.unsplash.com/photo-1769288361254-abb4783a6070?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBnYW1lJTIwbmlnaHQlMjBib2FyZCUyMGdhbWVzfGVufDF8fHx8MTc3Mzc1MjM1MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      },
      {
        id: 'group-3',
        name: 'Community Volunteers',
        description: 'Making a difference in our local community',
        isPrivate: false,
        creatorId: 'user-2',
        memberIds: ['user-1', 'user-2', 'user-7', 'user-8'],
        createdAt: new Date('2026-01-20').toISOString(),
        imageUrl: 'https://images.unsplash.com/photo-1751666526244-40239a251eae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2b2x1bnRlZXIlMjBjb21tdW5pdHklMjBzZXJ2aWNlfGVufDF8fHx8MTc3MzY1Mzg3NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      },
    ];
    storage.saveGroups(mockGroups);
    
    // Create mock events
    const mockEvents: Event[] = [
      {
        id: 'event-1',
        groupId: 'group-1',
        title: 'March Book Discussion',
        description: 'Discussing "The Midnight Library" by Matt Haig',
        date: '2026-03-25',
        time: '18:30',
        location: 'Central Library, Community Room',
        rsvpDeadline: '2026-03-23', // 2 days before event
        rsvpFields: [
          { id: 'field-1', label: 'Dietary Restrictions', type: 'text' },
          { id: 'field-2', label: 'Finished Reading?', type: 'select', options: ['Yes', 'No', 'Almost'] },
        ],
        signupSheets: [
          {
            id: 'sheet-1',
            title: 'Refreshments',
            type: 'potluck',
            deadline: '2026-03-24T12:00:00', // Day before event at noon
            items: [
              { id: 'item-1', description: 'Snacks', slots: 3, signedUp: [{ userId: 'user-2', userName: 'Emma Davis', quantity: 1 }] },
              { id: 'item-2', description: 'Beverages', slots: 2, signedUp: [] },
              { id: 'item-3', description: 'Desserts', slots: 2, signedUp: [] },
            ],
          },
        ],
        createdAt: new Date('2026-03-01').toISOString(),
        imageUrl: 'https://images.unsplash.com/photo-1669016020285-b2de13e1f0e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY2x1YiUyMG1lZXRpbmclMjBjb2ZmZWV8ZW58MXx8fHwxNzczNzUyMzUwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      },
      {
        id: 'event-2',
        groupId: 'group-2',
        title: 'Spring Game Tournament',
        description: 'Annual game night championship!',
        date: '2026-04-12',
        time: '19:00',
        location: 'Johnson Residence',
        rsvpFields: [
          { id: 'field-3', label: 'T-Shirt Size', type: 'select', options: ['XS', 'S', 'M', 'L', 'XL', 'XXL'] },
          { id: 'field-4', label: 'Age Group', type: 'select', options: ['Kids (5-12)', 'Teens (13-17)', 'Adults (18+)'] },
          { id: 'field-5', label: 'Special Requests', type: 'text' },
        ],
        signupSheets: [
          {
            id: 'sheet-2',
            title: 'Game Selection',
            type: 'game',
            items: [
              { id: 'item-4', description: 'Monopoly', slots: 6, signedUp: [{ userId: 'user-1', userName: 'Sarah Johnson', quantity: 1 }] },
              { id: 'item-5', description: 'Scrabble', slots: 4, signedUp: [] },
              { id: 'item-6', description: 'Charades', slots: 8, signedUp: [] },
            ],
          },
        ],
        createdAt: new Date('2026-03-10').toISOString(),
        imageUrl: 'https://images.unsplash.com/photo-1769288361254-abb4783a6070?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBnYW1lJTIwbmlnaHQlMjBib2FyZCUyMGdhbWVzfGVufDF8fHx8MTc3Mzc1MjM1MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      },
      {
        id: 'event-3',
        groupId: 'group-3',
        title: 'Park Cleanup Day',
        description: 'Help us clean up Riverside Park for spring!',
        date: '2026-04-05',
        time: '09:00',
        location: 'Riverside Park Main Entrance',
        rsvpFields: [
          { id: 'field-6', label: 'Will bring own gloves?', type: 'select', options: ['Yes', 'No - need gloves'] },
        ],
        signupSheets: [
          {
            id: 'sheet-3',
            title: 'Volunteer Roles',
            type: 'volunteer',
            items: [
              { id: 'item-7', description: 'Trash Collection', slots: 10, signedUp: [{ userId: 'user-1', userName: 'Sarah Johnson', quantity: 1 }] },
              { id: 'item-8', description: 'Recycling Sorting', slots: 5, signedUp: [] },
              { id: 'item-9', description: 'Team Leader', slots: 3, signedUp: [] },
            ],
          },
        ],
        createdAt: new Date('2026-03-15').toISOString(),
        imageUrl: 'https://images.unsplash.com/photo-1751666526244-40239a251eae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2b2x1bnRlZXIlMjBjb21tdW5pdHklMjBzZXJ2aWNlfGVufDF8fHx8MTc3MzY1Mzg3NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      },
    ];
    storage.saveEvents(mockEvents);
    
    // Create mock RSVPs
    const mockRSVPs: RSVP[] = [
      {
        id: 'rsvp-1',
        eventId: 'event-1',
        userId: 'user-1',
        userName: 'Sarah Johnson',
        attending: 'yes',
        guestCount: 0,
        guests: [],
        customFields: {
          'field-1': 'Vegetarian',
          'field-2': 'Yes',
        },
        createdAt: new Date('2026-03-05').toISOString(),
      },
      {
        id: 'rsvp-2',
        eventId: 'event-1',
        userId: 'user-2',
        userName: 'Emma Davis',
        attending: 'yes',
        guestCount: 2,
        guests: [
          { id: 'guest-1', name: 'Michael Davis' },
          { id: 'guest-2', name: 'Sophie Davis' },
        ],
        customFields: {
          'field-1': 'None',
          'field-2': 'Almost',
        },
        createdAt: new Date('2026-03-06').toISOString(),
      },
      {
        id: 'rsvp-3',
        eventId: 'event-1',
        userId: 'user-3',
        userName: 'Alex Thompson',
        attending: 'maybe',
        guestCount: 0,
        guests: [],
        customFields: {
          'field-2': 'No',
        },
        createdAt: new Date('2026-03-07').toISOString(),
      },
    ];
    storage.saveRSVPs(mockRSVPs);
    
    // Create mock messages
    const mockMessages: Message[] = [
      {
        id: 'msg-1',
        groupId: 'group-1',
        userId: 'user-2',
        userName: 'Emma Davis',
        content: 'Looking forward to our next meetup! Has everyone finished the book?',
        createdAt: new Date('2026-03-15T10:30:00').toISOString(),
      },
      {
        id: 'msg-2',
        groupId: 'group-1',
        userId: 'user-1',
        userName: 'Sarah Johnson',
        content: "I'm about halfway through - it's such a great read!",
        createdAt: new Date('2026-03-15T11:15:00').toISOString(),
      },
      {
        id: 'msg-3',
        eventId: 'event-1',
        userId: 'user-3',
        userName: 'Michael Chen',
        content: 'Can we meet 15 minutes earlier? I have a hard stop at 8pm.',
        createdAt: new Date('2026-03-16T14:20:00').toISOString(),
      },
    ];
    storage.saveMessages(mockMessages);
    
    // Create mock photos
    const mockPhotos: Photo[] = [
      {
        id: 'photo-1',
        eventId: 'event-1',
        url: 'https://images.unsplash.com/photo-1669016020285-b2de13e1f0e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY2x1YiUyMG1lZXRpbmclMjBjb2ZmZWV8ZW58MXx8fHwxNzczNzUyMzUwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        uploadedBy: 'Sarah Johnson',
        caption: 'Great discussion tonight!',
        createdAt: new Date('2026-02-25T21:30:00').toISOString(),
      },
      {
        id: 'photo-2',
        eventId: 'event-1',
        url: 'https://images.unsplash.com/photo-1760574740271-55e6683afe76?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwZ3JvdXAlMjBmcmllbmRzJTIwZ2F0aGVyaW5nfGVufDF8fHx8MTc3Mzc1MjM0OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        uploadedBy: 'Emma Davis',
        caption: 'The whole group together',
        createdAt: new Date('2026-02-25T21:45:00').toISOString(),
      },
    ];
    storage.savePhotos(mockPhotos);
  }
};