import { Group, Event, RSVP, Message, Photo, User } from '../types';
import { groupAPI, eventAPI, rsvpAPI, messageAPI, photoAPI, userAPI } from './supabaseClient';

// Cache for data to minimize API calls
let groupsCache: Group[] | null = null;
let eventsCache: Event[] | null = null;
let rsvpsCache: RSVP[] | null = null;
let messagesCache: Message[] | null = null;
let photosCache: Photo[] | null = null;
let currentUserCache: User | null = null;

// LocalStorage key for current user (still stored locally)
const CURRENT_USER_KEY = 'groupchat_current_user';

// Async storage helpers
export const storage = {
  // Groups
  getGroups: async (): Promise<Group[]> => {
    if (groupsCache) return groupsCache;
    try {
      const groups = await groupAPI.getAll();
      groupsCache = groups;
      return groups;
    } catch (error) {
      console.error('Error fetching groups:', error);
      return [];
    }
  },

  saveGroups: async (groups: Group[]): Promise<void> => {
    try {
      // Save each group individually
      for (const group of groups) {
        await groupAPI.update(group.id, group);
      }
      groupsCache = groups;
    } catch (error) {
      console.error('Error saving groups:', error);
    }
  },

  addGroup: async (group: Group): Promise<void> => {
    try {
      await groupAPI.create(group);
      groupsCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error adding group:', error);
    }
  },

  updateGroup: async (group: Group): Promise<void> => {
    try {
      await groupAPI.update(group.id, group);
      groupsCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error updating group:', error);
    }
  },

  deleteGroup: async (groupId: string): Promise<void> => {
    try {
      await groupAPI.delete(groupId);
      groupsCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error deleting group:', error);
    }
  },

  // Events
  getEvents: async (): Promise<Event[]> => {
    if (eventsCache) return eventsCache;
    try {
      const events = await eventAPI.getAll();
      eventsCache = events;
      return events;
    } catch (error) {
      console.error('Error fetching events:', error);
      return [];
    }
  },

  saveEvents: async (events: Event[]): Promise<void> => {
    try {
      for (const event of events) {
        await eventAPI.update(event.id, event);
      }
      eventsCache = events;
    } catch (error) {
      console.error('Error saving events:', error);
    }
  },

  addEvent: async (event: Event): Promise<void> => {
    try {
      await eventAPI.create(event);
      eventsCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error adding event:', error);
    }
  },

  updateEvent: async (event: Event): Promise<void> => {
    try {
      await eventAPI.update(event.id, event);
      eventsCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error updating event:', error);
    }
  },

  deleteEvent: async (eventId: string): Promise<void> => {
    try {
      await eventAPI.delete(eventId);
      eventsCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error deleting event:', error);
    }
  },

  // RSVPs
  getRSVPs: async (): Promise<RSVP[]> => {
    if (rsvpsCache) return rsvpsCache;
    try {
      const rsvps = await rsvpAPI.getAll();
      rsvpsCache = rsvps;
      return rsvps;
    } catch (error) {
      console.error('Error fetching RSVPs:', error);
      return [];
    }
  },

  saveRSVPs: async (rsvps: RSVP[]): Promise<void> => {
    try {
      for (const rsvp of rsvps) {
        await rsvpAPI.update(rsvp.id, rsvp);
      }
      rsvpsCache = rsvps;
    } catch (error) {
      console.error('Error saving RSVPs:', error);
    }
  },

  addRSVP: async (rsvp: RSVP): Promise<void> => {
    try {
      await rsvpAPI.create(rsvp);
      rsvpsCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error adding RSVP:', error);
    }
  },

  updateRSVP: async (rsvp: RSVP): Promise<void> => {
    try {
      await rsvpAPI.update(rsvp.id, rsvp);
      rsvpsCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error updating RSVP:', error);
    }
  },

  // Messages
  getMessages: async (): Promise<Message[]> => {
    if (messagesCache) return messagesCache;
    try {
      const messages = await messageAPI.getAll();
      messagesCache = messages;
      return messages;
    } catch (error) {
      console.error('Error fetching messages:', error);
      return [];
    }
  },

  saveMessages: async (messages: Message[]): Promise<void> => {
    messagesCache = messages;
    // Messages are typically added one at a time, so we don't need to update all
  },

  addMessage: async (message: Message): Promise<void> => {
    try {
      await messageAPI.create(message);
      messagesCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error adding message:', error);
    }
  },

  // Photos
  getPhotos: async (): Promise<Photo[]> => {
    if (photosCache) return photosCache;
    try {
      const photos = await photoAPI.getAll();
      photosCache = photos;
      return photos;
    } catch (error) {
      console.error('Error fetching photos:', error);
      return [];
    }
  },

  savePhotos: async (photos: Photo[]): Promise<void> => {
    photosCache = photos;
  },

  addPhoto: async (photo: Photo): Promise<void> => {
    try {
      await photoAPI.create(photo);
      photosCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error adding photo:', error);
    }
  },

  deletePhoto: async (photoId: string): Promise<void> => {
    try {
      await photoAPI.delete(photoId);
      photosCache = null; // Invalidate cache
    } catch (error) {
      console.error('Error deleting photo:', error);
    }
  },

  // Current User (still stored locally for session management)
  getCurrentUser: (): User | null => {
    if (currentUserCache) return currentUserCache;
    const data = localStorage.getItem(CURRENT_USER_KEY);
    const user = data ? JSON.parse(data) : null;
    currentUserCache = user;
    return user;
  },

  saveCurrentUser: (user: User) => {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    currentUserCache = user;
    // Also save to Supabase
    userAPI.update(user.id, user).catch(err => console.error('Error saving user to Supabase:', err));
  },

  // Clear all caches (useful for logout or refresh)
  clearCaches: () => {
    groupsCache = null;
    eventsCache = null;
    rsvpsCache = null;
    messagesCache = null;
    photosCache = null;
    currentUserCache = null;
  },
};

// Initialize with mock data if empty
export const initializeMockData = async () => {
  const groups = await storage.getGroups();

  if (groups.length === 0) {
    // Create mock user
    const mockUser: User = {
      id: 'user-1',
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
    };
    storage.saveCurrentUser(mockUser);
    await userAPI.create(mockUser);

    // Create mock groups
    const mockGroups: Group[] = [
      {
        id: 'group-1',
        name: 'Book Club Adventures',
        description: 'Monthly meetups to discuss our favorite books and authors',
        isPrivate: false,
        creatorId: 'user-1',
        memberIds: ['user-1', 'user-2', 'user-3', 'user-4'],
        createdAt: new Date('2026-01-15').toISOString(),
        imageUrl: 'https://images.unsplash.com/photo-1669016020285-b2de13e1f0e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rJTIwY2x1YiUyMG1lZXRpbmclMjBjb2ZmZWV8ZW58MXx8fHwxNzczNzUyMzUwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      },
      {
        id: 'group-2',
        name: 'Family Game Night',
        description: 'Weekly game nights with family and friends',
        isPrivate: true,
        joinCode: 'GAME2026',
        creatorId: 'user-1',
        memberIds: ['user-1', 'user-5', 'user-6'],
        createdAt: new Date('2026-02-01').toISOString(),
        imageUrl: 'https://images.unsplash.com/photo-1769288361254-abb4783a6070?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBnYW1lJTIwbmlnaHQlMjBib2FyZCUyMGdhbWVzfGVufDF8fHx8MTc3Mzc1MjM1MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      },
      {
        id: 'group-3',
        name: 'Community Volunteers',
        description: 'Making a difference in our local community',
        isPrivate: false,
        creatorId: 'user-2',
        memberIds: ['user-1', 'user-2', 'user-7', 'user-8'],
        createdAt: new Date('2026-01-20').toISOString(),
        imageUrl: 'https://images.unsplash.com/photo-1751666526244-40239a251eae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2b2x1bnRlZXIlMjBjb21tdW5pdHklMjBzZXJ2aWNlfGVufDF8fHx8MTc3MzY1Mzg3NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      },
    ];

    for (const group of mockGroups) {
      await groupAPI.create(group);
    }

    // Create mock events
    const mockEvents: Event[] = [
      {
        id: 'event-1',
        groupId: 'group-1',
        title: 'March Book Discussion',
        description: 'Discussing "The Midnight Library" by Matt Haig',
        date: '2026-05-25',
        time: '18:30',
        location: 'Central Library, Community Room',
        rsvpDeadline: '2026-05-23',
        rsvpFields: [
          { id: 'field-1', label: 'Dietary Restrictions', type: 'text' },
          { id: 'field-2', label: 'Finished Reading?', type: 'select', options: ['Yes', 'No', 'Almost'] },
        ],
        signupSheets: [],
        createdAt: new Date().toISOString(),
      },
    ];

    for (const event of mockEvents) {
      await eventAPI.create(event);
    }
  }
};
