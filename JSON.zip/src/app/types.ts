export interface GroupFile {
  id: string;
  name: string;
  url: string;
  uploadedBy: string;
  uploadedAt: string;
  size?: number;
}

export interface Group {
  id: string;
  name: string;
  description: string;
  isPrivate: boolean;
  joinCode?: string;
  creatorId: string;
  memberIds: string[];
  createdAt: string;
  imageUrl?: string;
  rules?: string[];
  files?: GroupFile[];
  photos?: Photo[];
}

export interface Event {
  id: string;
  groupId: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  rsvpDeadline?: string; // ISO date string
  rsvpFields: RSVPField[];
  signupSheets: SignupSheet[];
  createdAt: string;
  imageUrl?: string;
}

export interface RSVPField {
  id: string;
  label: string;
  type: 'text' | 'number' | 'select';
  options?: string[];
  required?: boolean;
}

export interface Guest {
  id: string;
  name: string;
  age?: string;
  customFields?: Record<string, any>;
}

export interface SavedGuest {
  id: string;
  name: string;
  relationship?: string; // e.g., "spouse", "child", "friend"
}

export interface RSVP {
  id: string;
  eventId: string;
  userId: string;
  userName: string;
  attending: 'yes' | 'maybe' | 'no';
  guestCount: number;
  guests: Guest[]; // Individual guest details
  customFields: Record<string, any>;
  createdAt: string;
}

export interface SignupSheet {
  id: string;
  title: string;
  type: 'potluck' | 'volunteer' | 'game' | 'other';
  items: SignupItem[];
  deadline?: string; // ISO date string
}

export interface SignupItem {
  id: string;
  description: string;
  slots: number;
  signedUp: SignupSlot[];
}

export interface SignupSlot {
  userId: string;
  userName: string;
  quantity: number;
}

export interface Message {
  id: string;
  groupId?: string;
  eventId?: string;
  userId: string;
  userName: string;
  content: string;
  createdAt: string;
}

export interface Photo {
  id: string;
  eventId: string;
  url: string;
  uploadedBy: string;
  caption?: string;
  createdAt: string;
}

export type SubscriptionTier = 'user' | 'standard' | 'corporate';

export interface User {
  id: string;
  name: string;
  email: string;
  savedGuests?: SavedGuest[]; // Saved guests for quick RSVP
  subscription?: SubscriptionTier; // Default is 'user' (free)
}