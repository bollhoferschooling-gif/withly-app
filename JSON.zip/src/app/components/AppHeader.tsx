import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Users, Calendar, User, Menu, X, Settings, Shield, LogOut } from 'lucide-react';
import { storage } from '../utils/storage';

export function AppHeader() {
  const navigate = useNavigate();
  const [showMenu, setShowMenu] = useState(false);
  const currentUser = storage.getCurrentUser();

  // For now, check if user is admin of any group
  const groups = storage.getGroups();
  const isAdminOfAnyGroup = groups.some(g => g.creatorId === currentUser?.id);

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    navigate('/login');
  };
  
  return (
    <header className="bg-[#F5F1EB] shadow-sm border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo - clickable to go home */}
          <Link to="/" className="flex items-center hover:opacity-80 transition-opacity">
            <img
              src="/src/imports/7DD84650-6C0D-45E9-AC41-82BE464CEF41.png"
              alt="Withly"
              className="h-20"
            />
          </Link>
          
          {/* Right side buttons */}
          <div className="flex items-center gap-3">
            <Link
              to="/calendar"
              className="flex items-center gap-2 px-4 py-2 bg-white text-[#2D2D2D] rounded-lg hover:bg-stone-100 transition-colors border border-stone-200"
            >
              <Calendar className="w-5 h-5" />
              <span className="hidden sm:inline">Calendar</span>
            </Link>
            <Link
              to="/profile"
              className="flex items-center gap-2 px-4 py-2 bg-white text-[#2D2D2D] rounded-lg hover:bg-stone-100 transition-colors border border-stone-200"
            >
              <User className="w-5 h-5" />
              <span className="hidden sm:inline">Profile</span>
            </Link>

            {/* Menu Button */}
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="flex items-center gap-2 px-4 py-2 bg-white text-[#2D2D2D] rounded-lg hover:bg-stone-100 transition-colors border border-stone-200"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Dropdown Side Menu */}
      {showMenu && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/50 z-40"
            onClick={() => setShowMenu(false)}
          />
          
          {/* Side Menu */}
          <div className="fixed top-0 right-0 h-full w-80 bg-white shadow-2xl z-50 transform transition-transform">
            <div className="flex flex-col h-full">
              {/* Menu Header */}
              <div className="flex items-center justify-between p-6 border-b">
                <h2 className="text-xl font-bold text-[#2D2D2D]">Menu</h2>
                <button
                  onClick={() => setShowMenu(false)}
                  className="text-[#9B9B9B] hover:text-[#2D2D2D]"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              {/* Menu Content */}
              <div className="flex-1 overflow-y-auto p-6">
                {isAdminOfAnyGroup ? (
                  /* Admin Menu */
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center gap-2 mb-4">
                        <Shield className="w-5 h-5 text-[#7FA090]" />
                        <h3 className="font-semibold text-[#2D2D2D]">Admin Tools</h3>
                      </div>
                      <div className="space-y-2">
                        <Link
                          to="/"
                          onClick={() => setShowMenu(false)}
                          className="block px-4 py-3 bg-[#FAFAF8] rounded-lg hover:bg-stone-100 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <Users className="w-5 h-5 text-[#7FA090]" />
                            <div>
                              <div className="font-medium text-[#2D2D2D]">My Groups</div>
                              <div className="text-xs text-[#9B9B9B]">Manage your groups</div>
                            </div>
                          </div>
                        </Link>
                        <Link
                          to="/profile"
                          onClick={() => setShowMenu(false)}
                          className="block px-4 py-3 bg-[#FAFAF8] rounded-lg hover:bg-stone-100 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <Settings className="w-5 h-5 text-[#7FA090]" />
                            <div>
                              <div className="font-medium text-[#2D2D2D]">Settings</div>
                              <div className="text-xs text-[#9B9B9B]">Manage your profile</div>
                            </div>
                          </div>
                        </Link>
                      </div>
                    </div>
                    
                    <div className="pt-6 border-t border-stone-200">
                      <div className="p-4 bg-[#FAFAF8] border border-[#7FA090] rounded-lg">
                        <div className="flex items-start gap-3">
                          <Shield className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                          <div>
                            <h4 className="font-semibold text-[#2D2D2D] mb-1">
                              Admin Account
                            </h4>
                            <p className="text-sm text-[#9B9B9B]">
                              You have admin privileges for managing groups and events.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Non-Admin Menu */
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-semibold text-[#2D2D2D] mb-4">Quick Links</h3>
                      <div className="space-y-2">
                        <Link
                          to="/"
                          onClick={() => setShowMenu(false)}
                          className="block px-4 py-3 bg-[#FAFAF8] rounded-lg hover:bg-stone-100 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <Users className="w-5 h-5 text-[#7FA090]" />
                            <div>
                              <div className="font-medium text-[#2D2D2D]">My Groups</div>
                              <div className="text-xs text-[#9B9B9B]">View all groups</div>
                            </div>
                          </div>
                        </Link>
                        <Link
                          to="/profile"
                          onClick={() => setShowMenu(false)}
                          className="block px-4 py-3 bg-[#FAFAF8] rounded-lg hover:bg-stone-100 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <Settings className="w-5 h-5 text-[#7FA090]" />
                            <div>
                              <div className="font-medium text-[#2D2D2D]">Settings</div>
                              <div className="text-xs text-[#9B9B9B]">Manage your profile</div>
                            </div>
                          </div>
                        </Link>
                      </div>
                    </div>
                    
                    {/* Upgrade to Admin Info */}
                    <div className="pt-6 border-t border-stone-200">
                      <div className="p-4 bg-[#FAFAF8] border border-[#7FA090] rounded-lg">
                        <div className="flex items-start gap-3 mb-3">
                          <Shield className="w-5 h-5 text-[#7FA090] flex-shrink-0 mt-0.5" />
                          <div>
                            <h4 className="font-semibold text-[#2D2D2D] mb-1">
                              Become an Admin
                            </h4>
                            <p className="text-sm text-[#9B9B9B] mb-3">
                              Create your own group to unlock admin features and manage events.
                            </p>
                          </div>
                        </div>
                        <ul className="space-y-2 mb-4">
                          <li className="text-sm text-[#2D2D2D] flex items-start gap-2">
                            <span className="text-[#7FA090] mt-0.5">✓</span>
                            <span>Create and manage groups</span>
                          </li>
                          <li className="text-sm text-[#2D2D2D] flex items-start gap-2">
                            <span className="text-[#7FA090] mt-0.5">✓</span>
                            <span>Organize events with custom signup sheets</span>
                          </li>
                          <li className="text-sm text-[#2D2D2D] flex items-start gap-2">
                            <span className="text-[#7FA090] mt-0.5">✓</span>
                            <span>Manage RSVPs and attendees</span>
                          </li>
                          <li className="text-sm text-[#2D2D2D] flex items-start gap-2">
                            <span className="text-[#7FA090] mt-0.5">✓</span>
                            <span>Private group options</span>
                          </li>
                        </ul>
                        <Link
                          to="/"
                          onClick={() => setShowMenu(false)}
                          className="block w-full px-4 py-2 bg-[#7FA090] text-white text-center rounded-lg hover:opacity-90 transition-opacity font-medium"
                        >
                          Create Your First Group
                        </Link>
                      </div>
                    </div>
                  </div>
                )}

                {/* Logout Button */}
                <div className="mt-6 pt-6 border-t border-stone-200">
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-3 w-full px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <LogOut className="w-5 h-5" />
                    <span className="font-medium">Log Out</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </header>
  );
}
