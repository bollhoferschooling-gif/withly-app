import { useState } from 'react';
import { useNavigate } from 'react-router';
import { X, Users } from 'lucide-react';
import { Group, Event } from '../types';
import { storage } from '../utils/storage';
import { CreateEventModal } from './CreateEventModal';

interface CreateEventFlowProps {
  onClose: () => void;
}

export function CreateEventFlow({ onClose }: CreateEventFlowProps) {
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [groups, setGroups] = useState<Group[]>(() => {
    const currentUser = storage.getCurrentUser();
    const allGroups = storage.getGroups();
    // Filter to show only groups where user is a member
    return allGroups.filter(group => 
      currentUser && group.memberIds.includes(currentUser.id)
    );
  });
  const navigate = useNavigate();

  const handleCreateEvent = (event: Event) => {
    const events = storage.getEvents();
    events.push(event);
    storage.saveEvents(events);
    
    // Navigate to the new event
    navigate(`/events/${event.id}`);
    onClose();
  };

  if (selectedGroupId) {
    return (
      <CreateEventModal
        groupId={selectedGroupId}
        onClose={onClose}
        onCreate={handleCreateEvent}
      />
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-lg w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-[#2D2D2D]">Select a Group</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-[#9B9B9B]">
            <X className="w-6 h-6" />
          </button>
        </div>

        <p className="text-[#9B9B9B] mb-6">
          Which group would you like to create an event for?
        </p>

        {groups.length === 0 ? (
          <div className="text-center py-8">
            <Users className="w-12 h-12 text-stone-300 mx-auto mb-3" />
            <p className="text-[#9B9B9B] mb-4">
              You need to be a member of a group to create events.
            </p>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors"
            >
              Close
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {groups.map((group) => (
              <button
                key={group.id}
                onClick={() => setSelectedGroupId(group.id)}
                className="w-full flex items-center gap-4 p-4 bg-[#F5F1EB] rounded-lg hover:bg-white transition-colors text-left"
              >
                {group.imageUrl ? (
                  <img
                    src={group.imageUrl}
                    alt={group.name}
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
                    <Users className="w-6 h-6 text-[#7FA090]" />
                  </div>
                )}
                <div className="flex-1">
                  <h3 className="font-semibold text-[#2D2D2D]">{group.name}</h3>
                  <p className="text-sm text-[#9B9B9B]">
                    {group.memberIds.length} {group.memberIds.length === 1 ? 'member' : 'members'}
                  </p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
