import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Check, X, HelpCircle, Plus, Trash2, UserPlus, Users } from 'lucide-react';
import { Event, RSVP, Guest, SavedGuest } from '../types';
import { storage } from '../utils/storage';

interface RSVPFormProps {
  event: Event;
  userRsvp?: RSVP;
  onRsvpSubmit: () => void;
}

export function RSVPForm({ event, userRsvp, onRsvpSubmit }: RSVPFormProps) {
  const navigate = useNavigate();
  const [attending, setAttending] = useState<'yes' | 'maybe' | 'no'>(userRsvp?.attending ?? 'yes');
  const [guestCount, setGuestCount] = useState(userRsvp?.guestCount ?? 0);
  const [guests, setGuests] = useState<Guest[]>(userRsvp?.guests ?? []);
  const [customFields, setCustomFields] = useState<Record<string, any>>(
    userRsvp?.customFields ?? {}
  );
  const [showForm, setShowForm] = useState(!userRsvp);
  const [saveGuestsToProfile, setSaveGuestsToProfile] = useState(false);
  const [saveSetupForFuture, setSaveSetupForFuture] = useState(false);
  const [showSavedGuestsMenu, setShowSavedGuestsMenu] = useState(false);
  const currentUser = storage.getCurrentUser();
  
  // Get last RSVP from same group
  const getLastGroupRSVP = (): RSVP | null => {
    if (!currentUser || userRsvp) return null;
    
    const allEvents = storage.getEvents();
    const groupEvents = allEvents
      .filter(e => e.groupId === event.groupId && e.id !== event.id)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    if (groupEvents.length === 0) return null;
    
    const allRsvps = storage.getRSVPs();
    for (const groupEvent of groupEvents) {
      const rsvp = allRsvps.find(r => r.eventId === groupEvent.id && r.userId === currentUser.id);
      if (rsvp && rsvp.attending === 'yes' && (rsvp.guestCount > 0 || rsvp.guests?.length > 0)) {
        return rsvp;
      }
    }
    
    return null;
  };
  
  const lastGroupRSVP = getLastGroupRSVP();
  
  const applyLastRSVP = () => {
    if (!lastGroupRSVP) return;
    
    setAttending('yes');
    setGuestCount(lastGroupRSVP.guestCount);
    setGuests(lastGroupRSVP.guests || []);
    setSaveSetupForFuture(true);
  };
  
  useEffect(() => {
    if (userRsvp) {
      setAttending(userRsvp.attending);
      setGuestCount(userRsvp.guestCount);
      setGuests(userRsvp.guests || []);
      setCustomFields(userRsvp.customFields);
    }
  }, [userRsvp]);
  
  useEffect(() => {
    // Adjust guests array when guestCount changes
    if (guests.length < guestCount) {
      const newGuests = [...guests];
      for (let i = guests.length; i < guestCount; i++) {
        newGuests.push({ id: `guest-${Date.now()}-${i}`, name: '' });
      }
      setGuests(newGuests);
    } else if (guests.length > guestCount) {
      setGuests(guests.slice(0, guestCount));
    }
  }, [guestCount]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) return;
    
    const rsvp: RSVP = {
      id: userRsvp?.id || `rsvp-${Date.now()}`,
      eventId: event.id,
      userId: currentUser.id,
      userName: currentUser.name,
      attending,
      guestCount: attending === 'yes' ? guestCount : 0,
      guests: attending === 'yes' ? guests.filter(g => g.name.trim()) : [],
      customFields: attending !== 'no' ? customFields : {},
      createdAt: userRsvp?.createdAt || new Date().toISOString(),
    };
    
    const allRsvps = storage.getRSVPs();
    const existingIndex = allRsvps.findIndex(r => r.id === rsvp.id);
    
    if (existingIndex >= 0) {
      allRsvps[existingIndex] = rsvp;
    } else {
      allRsvps.push(rsvp);
    }
    
    storage.saveRSVPs(allRsvps);
    
    // Save guests to user profile if requested
    if (saveGuestsToProfile && attending === 'yes' && guests.length > 0) {
      const validGuests = guests.filter(g => g.name.trim());
      if (validGuests.length > 0) {
        const updatedUser = { 
          ...currentUser, 
          savedGuests: [
            ...(currentUser.savedGuests || []),
            ...validGuests.map(g => ({
              id: `saved-${Date.now()}-${Math.random()}`,
              name: g.name,
              relationship: g.age ? `Age ${g.age}` : undefined
            } as SavedGuest))
          ].filter((guest, index, self) => 
            index === self.findIndex(g => g.name === guest.name)
          ) // Remove duplicates
        };
        storage.saveCurrentUser(updatedUser);
      }
    }
    
    setShowForm(false);
    onRsvpSubmit();
    
    // Navigate to confirmation page
    if (attending === 'yes') {
      navigate(`/events/${event.id}/rsvp-confirmed`);
    }
  };
  
  const handleFieldChange = (fieldId: string, value: any) => {
    setCustomFields({
      ...customFields,
      [fieldId]: value,
    });
  };

  const handleGuestNameChange = (index: number, name: string) => {
    const updatedGuests = [...guests];
    updatedGuests[index] = { ...updatedGuests[index], name };
    setGuests(updatedGuests);
  };

  const handleGuestFieldChange = (guestIndex: number, fieldId: string, value: any) => {
    const updatedGuests = [...guests];
    updatedGuests[guestIndex] = {
      ...updatedGuests[guestIndex],
      customFields: {
        ...(updatedGuests[guestIndex].customFields || {}),
        [fieldId]: value,
      },
    };
    setGuests(updatedGuests);
  };
  
  const addSavedGuestToList = (savedGuest: SavedGuest) => {
    if (guestCount < 20) {
      setGuestCount(guestCount + 1);
      // The useEffect will add a new guest, then we update it
      setTimeout(() => {
        const updatedGuests = [...guests];
        updatedGuests[guestCount] = { 
          id: `guest-${Date.now()}`, 
          name: savedGuest.name 
        };
        setGuests(updatedGuests);
      }, 0);
    }
    setShowSavedGuestsMenu(false);
  };
  
  if (userRsvp && !showForm) {
    return (
      <div className="space-y-4">
        <div className={`p-6 rounded-lg border-2 ${
          userRsvp.attending === 'yes'
            ? 'bg-green-50 border-green-200' 
            : userRsvp.attending === 'maybe'
            ? 'bg-yellow-50 border-yellow-200'
            : 'bg-[#F5F1EB] border-stone-200'
        }`}>
          <div className="flex items-center gap-3 mb-4">
            {userRsvp.attending === 'yes' ? (
              <>
                <Check className="w-6 h-6 text-green-600" />
                <span className="text-lg font-semibold text-green-900">
                  You're going!
                </span>
              </>
            ) : userRsvp.attending === 'maybe' ? (
              <>
                <HelpCircle className="w-6 h-6 text-yellow-600" />
                <span className="text-lg font-semibold text-yellow-900">
                  You might attend
                </span>
              </>
            ) : (
              <>
                <X className="w-6 h-6 text-[#9B9B9B]" />
                <span className="text-lg font-semibold text-[#2D2D2D]">
                  You're not attending
                </span>
              </>
            )}
          </div>
          
          {userRsvp.attending !== 'no' && (
            <div className="space-y-3 mb-4">
              {/* Main Attendee Custom Fields */}
              {Object.keys(userRsvp.customFields).length > 0 && (
                <div className="pb-2 border-b border-stone-200">
                  <p className="text-sm font-semibold text-[#2D2D2D] mb-2">{currentUser?.name || 'You'}</p>
                  {event.rsvpFields.map((field) => {
                    const value = userRsvp.customFields[field.id];
                    if (!value) return null;

                    return (
                      <p key={field.id} className="text-sm text-[#9B9B9B] ml-3">
                        <span className="font-medium">{field.label}:</span> {value}
                      </p>
                    );
                  })}
                </div>
              )}

              {userRsvp.guests && userRsvp.guests.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-[#2D2D2D] mb-2">Guests:</p>
                  <div className="space-y-3">
                    {userRsvp.guests.map((guest, index) => (
                      <div key={guest.id} className="ml-3 pb-2 border-b border-stone-100 last:border-0">
                        <p className="text-sm font-medium text-[#2D2D2D]">• {guest.name}</p>
                        {guest.customFields && Object.keys(guest.customFields).length > 0 && (
                          <div className="ml-4 mt-1 space-y-0.5">
                            {event.rsvpFields.map((field) => {
                              const value = guest.customFields?.[field.id];
                              if (!value) return null;

                              return (
                                <p key={field.id} className="text-xs text-[#9B9B9B]">
                                  <span className="font-medium">{field.label}:</span> {value}
                                </p>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
          
          <button
            onClick={() => setShowForm(true)}
            className="text-sm text-[#7FA090] hover:text-blue-700 font-medium"
          >
            Change RSVP
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Use Last RSVP Card */}
      {lastGroupRSVP && (
        <div className="bg-[#7FA090]/10 border-2 border-[#7FA090]/30 rounded-lg p-5">
          <h3 className="text-base font-semibold text-[#2D2D2D] mb-3">
            Use your last RSVP for this group?
          </h3>
          
          <div className="mb-4">
            <p className="text-sm font-medium text-[#2D2D2D] mb-2">Checked attendees:</p>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-[#2D2D2D]">
                <Check className="w-4 h-4 text-green-600" />
                <span>{currentUser?.name}</span>
              </div>
              {lastGroupRSVP.guests && lastGroupRSVP.guests.map((guest) => (
                <div key={guest.id} className="flex items-center gap-2 text-sm text-[#2D2D2D] ml-6">
                  <Check className="w-4 h-4 text-green-600" />
                  <span>{guest.name}</span>
                </div>
              ))}
            </div>
          </div>
          
          <button
            type="button"
            onClick={applyLastRSVP}
            className="w-full px-4 py-2.5 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors font-medium"
          >
            Use This
          </button>
        </div>
      )}
      
      <div>
        <label className="block text-sm font-medium text-[#2D2D2D] mb-3">
          Will you attend this event? *
        </label>
        <div className="grid grid-cols-3 gap-3">
          <button
            type="button"
            onClick={() => setAttending('yes')}
            className={`px-4 py-3 rounded-lg border-2 transition-all ${
              attending === 'yes'
                ? 'bg-green-50 border-green-500 text-green-900'
                : 'border-stone-300 text-[#2D2D2D] hover:border-slate-400'
            }`}
          >
            <Check className="w-5 h-5 mx-auto mb-1" />
            <span className="text-sm">Yes</span>
          </button>
          <button
            type="button"
            onClick={() => setAttending('maybe')}
            className={`px-4 py-3 rounded-lg border-2 transition-all ${
              attending === 'maybe'
                ? 'bg-yellow-50 border-yellow-500 text-yellow-900'
                : 'border-stone-300 text-[#2D2D2D] hover:border-slate-400'
            }`}
          >
            <HelpCircle className="w-5 h-5 mx-auto mb-1" />
            <span className="text-sm">Maybe</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setAttending('no');
              setGuestCount(0);
              setGuests([]);
              setCustomFields({});
            }}
            className={`px-4 py-3 rounded-lg border-2 transition-all ${
              attending === 'no'
                ? 'bg-[#F5F1EB] border-slate-500 text-[#2D2D2D]'
                : 'border-stone-300 text-[#2D2D2D] hover:border-slate-400'
            }`}
          >
            <X className="w-5 h-5 mx-auto mb-1" />
            <span className="text-sm">No</span>
          </button>
        </div>
      </div>
      
      {attending === 'yes' && (
        <>
          {/* Main Attendee Custom Fields */}
          {event.rsvpFields.length > 0 && (
            <div className="border-2 border-[#7FA090]/30 rounded-lg p-4 bg-[#7FA090]/5">
              <h3 className="font-medium text-[#2D2D2D] mb-3 flex items-center gap-2">
                <Users className="w-5 h-5" />
                {currentUser?.name || 'You'}
              </h3>
              <div className="space-y-3">
                {event.rsvpFields.map((field) => (
                  <div key={field.id}>
                    <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                      {field.label} {field.required && '*'}
                    </label>

                    {field.type === 'text' && (
                      <input
                        type="text"
                        value={customFields[field.id] || ''}
                        onChange={(e) => handleFieldChange(field.id, e.target.value)}
                        required={field.required}
                        className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                      />
                    )}

                    {field.type === 'number' && (
                      <input
                        type="number"
                        value={customFields[field.id] || ''}
                        onChange={(e) => handleFieldChange(field.id, e.target.value)}
                        required={field.required}
                        className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                      />
                    )}

                    {field.type === 'select' && field.options && (
                      <select
                        value={customFields[field.id] || ''}
                        onChange={(e) => handleFieldChange(field.id, e.target.value)}
                        required={field.required}
                        className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                      >
                        <option value="">Select an option...</option>
                        {field.options.map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-[#2D2D2D]">
                Number of Additional Guests
              </label>
              {currentUser?.savedGuests && currentUser.savedGuests.length > 0 && (
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowSavedGuestsMenu(!showSavedGuestsMenu)}
                    className="text-sm text-[#7FA090] hover:text-blue-700 font-medium flex items-center gap-1"
                  >
                    <UserPlus className="w-4 h-4" />
                    Add Saved Guest
                  </button>
                  {showSavedGuestsMenu && (
                    <div className="absolute right-0 top-full mt-1 bg-white border border-stone-200 rounded-lg shadow-lg z-10 min-w-[200px] max-h-[200px] overflow-y-auto">
                      {currentUser.savedGuests.map((savedGuest) => (
                        <button
                          key={savedGuest.id}
                          type="button"
                          onClick={() => addSavedGuestToList(savedGuest)}
                          className="w-full text-left px-4 py-2 hover:bg-[#F5F1EB] text-sm"
                        >
                          <div className="font-medium text-[#2D2D2D]">{savedGuest.name}</div>
                          {savedGuest.relationship && (
                            <div className="text-xs text-[#9B9B9B]">{savedGuest.relationship}</div>
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
            <p className="text-xs text-[#9B9B9B] mb-3">
              Include family members, children, or other guests not on the app
            </p>
            <input
              type="number"
              min="0"
              max="20"
              value={guestCount}
              onChange={(e) => setGuestCount(parseInt(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
            />
          </div>

          {guestCount > 0 && (
            <div className="space-y-4">
              {guests.map((guest, index) => (
                <div key={guest.id} className="border-2 border-stone-200 rounded-lg p-4 bg-[#F5F1EB]">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-sm font-medium text-[#9B9B9B]">Guest {index + 1}</span>
                    <input
                      type="text"
                      placeholder="Guest name"
                      value={guest.name}
                      onChange={(e) => handleGuestNameChange(index, e.target.value)}
                      className="flex-1 px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                    />
                  </div>

                  {event.rsvpFields.length > 0 && (
                    <div className="space-y-3">
                      {event.rsvpFields.map((field) => (
                        <div key={field.id}>
                          <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                            {field.label} {field.required && '*'}
                          </label>

                          {field.type === 'text' && (
                            <input
                              type="text"
                              value={guest.customFields?.[field.id] || ''}
                              onChange={(e) => handleGuestFieldChange(index, field.id, e.target.value)}
                              required={field.required}
                              className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                            />
                          )}

                          {field.type === 'number' && (
                            <input
                              type="number"
                              value={guest.customFields?.[field.id] || ''}
                              onChange={(e) => handleGuestFieldChange(index, field.id, e.target.value)}
                              required={field.required}
                              className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                            />
                          )}

                          {field.type === 'select' && field.options && (
                            <select
                              value={guest.customFields?.[field.id] || ''}
                              onChange={(e) => handleGuestFieldChange(index, field.id, e.target.value)}
                              required={field.required}
                              className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                            >
                              <option value="">Select an option...</option>
                              {field.options.map((option) => (
                                <option key={option} value={option}>
                                  {option}
                                </option>
                              ))}
                            </select>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              {guests.some(g => g.name.trim()) && (
                <div>
                  <label className="flex items-center gap-2 text-sm text-[#2D2D2D] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={saveGuestsToProfile}
                      onChange={(e) => setSaveGuestsToProfile(e.target.checked)}
                      className="w-4 h-4 text-[#7FA090] rounded focus:ring-2 focus:ring-[#7FA090]"
                    />
                    <span>Save Guests for Future RSVPs</span>
                  </label>
                </div>
              )}
            </div>
          )}
        </>
      )}
      
      {attending === 'maybe' && (
        <>
          {event.rsvpFields.map((field) => (
            <div key={field.id}>
              <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                {field.label} {field.required && '*'}
              </label>
              
              {field.type === 'text' && (
                <input
                  type="text"
                  value={customFields[field.id] || ''}
                  onChange={(e) => handleFieldChange(field.id, e.target.value)}
                  required={field.required}
                  className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                />
              )}
              
              {field.type === 'number' && (
                <input
                  type="number"
                  value={customFields[field.id] || ''}
                  onChange={(e) => handleFieldChange(field.id, e.target.value)}
                  required={field.required}
                  className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                />
              )}
              
              {field.type === 'select' && field.options && (
                <select
                  value={customFields[field.id] || ''}
                  onChange={(e) => handleFieldChange(field.id, e.target.value)}
                  required={field.required}
                  className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                >
                  <option value="">Select an option...</option>
                  {field.options.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              )}
            </div>
          ))}
        </>
      )}
      
      {/* Save Setup Toggle */}
      {attending === 'yes' && guestCount > 0 && (
        <div className="border-t pt-4">
          <label className="flex items-center gap-2 text-sm text-[#2D2D2D] cursor-pointer">
            <input
              type="checkbox"
              checked={saveSetupForFuture}
              onChange={(e) => setSaveSetupForFuture(e.target.checked)}
              className="w-4 h-4 text-[#7FA090] rounded focus:ring-2 focus:ring-[#7FA090]"
            />
            <span>Save this setup for future RSVPs</span>
          </label>
        </div>
      )}
      
      <div className="flex gap-3 pt-4">
        {userRsvp && (
          <button
            type="button"
            onClick={() => setShowForm(false)}
            className="flex-1 px-4 py-2 border border-stone-300 text-[#2D2D2D] rounded-lg hover:bg-[#F5F1EB] transition-colors"
          >
            Cancel
          </button>
        )}
        <button
          type="submit"
          className="flex-1 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors"
        >
          {userRsvp ? 'Update RSVP' : 'Submit RSVP'}
        </button>
      </div>
    </form>
  );
}