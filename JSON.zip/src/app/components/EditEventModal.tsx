import { useState } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';
import { Event, RSVPField, SignupSheet, SignupItem } from '../types';

interface EditEventModalProps {
  event: Event;
  onClose: () => void;
  onUpdate: (event: Event) => void;
}

export function EditEventModal({ event, onClose, onUpdate }: EditEventModalProps) {
  const [title, setTitle] = useState(event.title);
  const [description, setDescription] = useState(event.description);
  const [date, setDate] = useState(event.date);
  const [time, setTime] = useState(event.time);
  const [location, setLocation] = useState(event.location);
  const [rsvpFields, setRsvpFields] = useState<RSVPField[]>(event.rsvpFields || []);
  const [signupSheets, setSignupSheets] = useState<SignupSheet[]>(event.signupSheets || []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const updatedEvent: Event = {
      ...event,
      title,
      description,
      date,
      time,
      location,
      rsvpFields,
      signupSheets,
    };

    onUpdate(updatedEvent);
  };

  const addRSVPField = () => {
    setRsvpFields([
      ...rsvpFields,
      {
        id: `field-${Date.now()}`,
        label: '',
        type: 'text',
        required: false,
      },
    ]);
  };

  const removeRSVPField = (id: string) => {
    setRsvpFields(rsvpFields.filter(f => f.id !== id));
  };

  const updateRSVPField = (id: string, updates: Partial<RSVPField>) => {
    setRsvpFields(rsvpFields.map(f => f.id === id ? { ...f, ...updates } : f));
  };

  const addOptionToField = (fieldId: string) => {
    setRsvpFields(rsvpFields.map(f => {
      if (f.id === fieldId) {
        return {
          ...f,
          options: [...(f.options || []), '']
        };
      }
      return f;
    }));
  };

  const updateFieldOption = (fieldId: string, optionIndex: number, value: string) => {
    setRsvpFields(rsvpFields.map(f => {
      if (f.id === fieldId && f.options) {
        const newOptions = [...f.options];
        newOptions[optionIndex] = value;
        return { ...f, options: newOptions };
      }
      return f;
    }));
  };

  const removeFieldOption = (fieldId: string, optionIndex: number) => {
    setRsvpFields(rsvpFields.map(f => {
      if (f.id === fieldId && f.options) {
        return {
          ...f,
          options: f.options.filter((_, i) => i !== optionIndex)
        };
      }
      return f;
    }));
  };

  const addSignupSheet = () => {
    setSignupSheets([
      ...signupSheets,
      {
        id: `sheet-${Date.now()}`,
        title: '',
        type: 'other',
        items: [],
      },
    ]);
  };

  const removeSignupSheet = (id: string) => {
    setSignupSheets(signupSheets.filter(s => s.id !== id));
  };

  const updateSignupSheet = (id: string, updates: Partial<SignupSheet>) => {
    setSignupSheets(signupSheets.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  const addItemToSheet = (sheetId: string) => {
    setSignupSheets(signupSheets.map(sheet => {
      if (sheet.id === sheetId) {
        return {
          ...sheet,
          items: [
            ...sheet.items,
            {
              id: `item-${Date.now()}`,
              description: '',
              slots: 1,
              signedUp: [],
            },
          ],
        };
      }
      return sheet;
    }));
  };

  const removeItemFromSheet = (sheetId: string, itemId: string) => {
    setSignupSheets(signupSheets.map(sheet => {
      if (sheet.id === sheetId) {
        return {
          ...sheet,
          items: sheet.items.filter(item => item.id !== itemId),
        };
      }
      return sheet;
    }));
  };

  const updateSheetItem = (sheetId: string, itemId: string, updates: Partial<SignupItem>) => {
    setSignupSheets(signupSheets.map(sheet => {
      if (sheet.id === sheetId) {
        return {
          ...sheet,
          items: sheet.items.map(item =>
            item.id === itemId ? { ...item, ...updates } : item
          ),
        };
      }
      return sheet;
    }));
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-xl max-w-2xl w-full p-6 my-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-[#2D2D2D]">Edit Event</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-[#9B9B9B]">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} onKeyDown={(e) => {
          if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
          }
        }} className="space-y-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <h3 className="font-semibold text-[#2D2D2D]">Event Details</h3>

            <div>
              <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                Event Title *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                placeholder="e.g., Summer Picnic"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                Description *
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                rows={3}
                className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                placeholder="What's this event about?"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                  Date *
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                  Time *
                </label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  required
                  className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                Location *
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                required
                className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                placeholder="Where will this event take place?"
              />
            </div>
          </div>

          {/* RSVP Fields */}
          <div className="space-y-4 border-t pt-6">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-[#2D2D2D]">Custom RSVP Fields</h3>
              <button
                type="button"
                onClick={addRSVPField}
                className="flex items-center gap-2 px-3 py-1.5 text-sm bg-white text-[#2D2D2D] rounded-lg hover:bg-slate-200 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Field
              </button>
            </div>

            {rsvpFields.map((field, index) => (
              <div key={field.id} className="flex gap-3 p-4 bg-[#F5F1EB] rounded-lg">
                <div className="flex-1 space-y-3">
                  <input
                    type="text"
                    value={field.label}
                    onChange={(e) => updateRSVPField(field.id, { label: e.target.value })}
                    placeholder="Field label (e.g., T-Shirt Size, Dietary Restrictions)"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                  />
                  <select
                    value={field.type}
                    onChange={(e) => {
                      const newType = e.target.value as 'text' | 'number' | 'select';
                      updateRSVPField(field.id, {
                        type: newType,
                        options: newType === 'select' ? ['', ''] : undefined
                      });
                    }}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                  >
                    <option value="text">Text Input</option>
                    <option value="number">Number</option>
                    <option value="select">Multiple Choice</option>
                  </select>
                  {field.type === 'select' && (
                    <div className="space-y-2">
                      <label className="text-sm text-[#9B9B9B]">Choices:</label>
                      {(field.options || []).map((option, optionIndex) => (
                        <div key={optionIndex} className="flex gap-2">
                          <input
                            type="text"
                            placeholder={`Choice ${optionIndex + 1}`}
                            value={option}
                            onChange={(e) => updateFieldOption(field.id, optionIndex, e.target.value)}
                            className="flex-1 px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                          />
                          {field.options && field.options.length > 2 && (
                            <button
                              type="button"
                              onClick={() => removeFieldOption(field.id, optionIndex)}
                              className="text-red-500 hover:text-red-700 p-2"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      ))}
                      <button
                        type="button"
                        onClick={() => addOptionToField(field.id)}
                        className="flex items-center gap-2 px-3 py-2 text-sm bg-white border border-stone-300 text-[#7FA090] rounded-lg hover:bg-stone-50 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                        Add Choice
                      </button>
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => removeRSVPField(field.id)}
                  className="text-red-500 hover:text-red-700"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-stone-300 text-[#2D2D2D] rounded-lg hover:bg-[#F5F1EB] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors"
            >
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
