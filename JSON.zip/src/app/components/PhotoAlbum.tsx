import { useState, useEffect } from 'react';
import { Upload, X, Clock } from 'lucide-react';
import { Photo } from '../types';
import { storage } from '../utils/storage';

interface PhotoAlbumProps {
  eventId: string;
}

export function PhotoAlbum({ eventId }: PhotoAlbumProps) {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [showUploadNote, setShowUploadNote] = useState(false);
  const currentUser = storage.getCurrentUser();
  
  useEffect(() => {
    loadPhotos();
  }, [eventId]);
  
  const loadPhotos = () => {
    const allPhotos = storage.getPhotos();
    const eventPhotos = allPhotos.filter(p => p.eventId === eventId);
    setPhotos(eventPhotos.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ));
  };
  
  const handleUploadClick = () => {
    setShowUploadNote(true);
    setTimeout(() => setShowUploadNote(false), 3000);
  };
  
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  };
  
  return (
    <div className="space-y-6">
      {/* Upload Section */}
      <div>
        <button
          onClick={handleUploadClick}
          className="w-full px-4 py-8 border-2 border-dashed border-stone-300 rounded-lg hover:border-blue-400 hover:bg-[#7FA090]/10 transition-colors flex flex-col items-center gap-2 text-[#9B9B9B] hover:text-[#7FA090]"
        >
          <Upload className="w-8 h-8" />
          <span className="font-medium">Upload Photos</span>
          <span className="text-sm">Click to add photos from this event</span>
        </button>
        
        {showUploadNote && (
          <div className="mt-3 p-3 bg-[#7FA090]/10 border border-[#7FA090]/30 rounded-lg text-sm text-blue-800">
            In a production app, this would open a file picker to upload photos. For this prototype, we're showing example photos.
          </div>
        )}
      </div>
      
      {/* Photos Grid */}
      {photos.length === 0 ? (
        <div className="text-center py-12 text-[#9B9B9B]">
          <p>No photos yet</p>
          <p className="text-sm">Be the first to add photos from this event!</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {photos.map((photo, index) => (
            <button
              key={photo.id}
              onClick={() => setSelectedPhoto(photo)}
              className="aspect-square rounded-lg overflow-hidden hover:opacity-90 transition-opacity relative"
            >
              <img
                src={photo.url}
                alt={photo.caption || 'Event photo'}
                className="w-full h-full object-cover"
              />
              {/* Pending approval label (show on first photo as example) */}
              {index === 0 && (
                <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-1 bg-orange-100 text-orange-700 rounded text-xs font-medium">
                  <Clock className="w-3 h-3" />
                  <span>Pending approval</span>
                </div>
              )}
            </button>
          ))}
        </div>
      )}
      
      {/* Photo Modal */}
      {selectedPhoto && (
        <div 
          className="fixed inset-0 bg-black/90 flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedPhoto(null)}
        >
          <div 
            className="max-w-4xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <button
                onClick={() => setSelectedPhoto(null)}
                className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors z-10"
              >
                <X className="w-6 h-6" />
              </button>
              
              <img
                src={selectedPhoto.url}
                alt={selectedPhoto.caption || 'Event photo'}
                className="w-full h-auto rounded-lg"
              />
              
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 rounded-b-lg">
                {selectedPhoto.caption && (
                  <p className="text-white text-lg mb-2">{selectedPhoto.caption}</p>
                )}
                <div className="flex items-center justify-between text-sm text-white/80">
                  <span>Uploaded by {selectedPhoto.uploadedBy}</span>
                  <span>{formatDate(selectedPhoto.createdAt)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}