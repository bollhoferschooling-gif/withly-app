import { useState, useEffect, useRef } from 'react';
import { Send, Pin } from 'lucide-react';
import { Message } from '../types';
import { storage } from '../utils/storage';

interface MessageThreadProps {
  groupId?: string;
  eventId?: string;
}

export function MessageThread({ groupId, eventId }: MessageThreadProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const currentUser = storage.getCurrentUser();
  
  useEffect(() => {
    loadMessages();
  }, [groupId, eventId]);
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const loadMessages = () => {
    const allMessages = storage.getMessages();
    const filtered = allMessages.filter(m => 
      (groupId && m.groupId === groupId && !m.eventId) ||
      (eventId && m.eventId === eventId)
    );
    setMessages(filtered.sort((a, b) => 
      new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    ));
  };
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !currentUser) return;
    
    const message: Message = {
      id: `msg-${Date.now()}`,
      groupId,
      eventId,
      userId: currentUser.id,
      userName: currentUser.name,
      content: newMessage.trim(),
      createdAt: new Date().toISOString(),
    };
    
    const allMessages = storage.getMessages();
    allMessages.push(message);
    storage.saveMessages(allMessages);
    
    setNewMessage('');
    loadMessages();
  };
  
  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 24) {
      return date.toLocaleTimeString('en-US', { 
        hour: 'numeric',
        minute: '2-digit'
      });
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit'
      });
    }
  };
  
  return (
    <div className="flex flex-col h-[500px]">
      {/* Pinned Message Banner */}
      {eventId && (
        <div className="mb-4 bg-yellow-50 border border-yellow-200 rounded-lg p-3 flex items-start gap-3">
          <Pin className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-medium text-yellow-900 mb-1">Pinned Message</p>
            <p className="text-sm text-yellow-800">
              Please RSVP by March 23rd! Don't forget to sign up for refreshments.
            </p>
          </div>
        </div>
      )}
      
      {/* Messages */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
        {messages.length === 0 ? (
          <div className="text-center py-8 text-[#9B9B9B]">
            <p>No messages yet</p>
            <p className="text-sm">Start the conversation!</p>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`flex flex-col ${
                message.userId === currentUser?.id ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[80%] rounded-lg px-4 py-2 ${
                  message.userId === currentUser?.id
                    ? 'bg-[#7FA090] text-white'
                    : 'bg-white text-[#2D2D2D]'
                }`}
              >
                {message.userId !== currentUser?.id && (
                  <p className="text-xs font-semibold mb-1 opacity-75">
                    {message.userName}
                  </p>
                )}
                <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>
              </div>
              <span className="text-xs text-[#9B9B9B] mt-1 px-2">
                {formatTime(message.createdAt)}
              </span>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Input */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type a message..."
          className="flex-1 px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
        />
        <button
          type="submit"
          disabled={!newMessage.trim()}
          className="px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
}