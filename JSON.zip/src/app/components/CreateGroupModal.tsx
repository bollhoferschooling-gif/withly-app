import { useState } from 'react';
import { X } from 'lucide-react';
import { Group } from '../types';
import { storage } from '../utils/storage';

interface CreateGroupModalProps {
  onClose: () => void;
  onCreate: (group: Group) => void;
}

export function CreateGroupModal({ onClose, onCreate }: CreateGroupModalProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  
  const currentUser = storage.getCurrentUser();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newGroup: Group = {
      id: `group-${Date.now()}`,
      name,
      description,
      isPrivate,
      joinCode: isPrivate ? generateJoinCode() : undefined,
      creatorId: currentUser?.id || 'user-1',
      memberIds: [currentUser?.id || 'user-1'],
      createdAt: new Date().toISOString(),
    };
    
    onCreate(newGroup);
  };
  
  const generateJoinCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-[#2D2D2D]">Create New Group</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-[#9B9B9B]">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
              Group Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
              placeholder="e.g., Book Club, Soccer Team"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
              Description *
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              rows={3}
              className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
              placeholder="Tell members what this group is about..."
            />
          </div>
          
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="isPrivate"
              checked={isPrivate}
              onChange={(e) => setIsPrivate(e.target.checked)}
              className="w-4 h-4 text-[#7FA090] rounded focus:ring-2 focus:ring-[#7FA090]"
            />
            <label htmlFor="isPrivate" className="text-sm text-[#2D2D2D]">
              Make this group private (requires join code)
            </label>
          </div>
          
          {isPrivate && (
            <div className="bg-[#7FA090]/10 border border-[#7FA090]/30 rounded-lg p-4">
              <p className="text-sm text-blue-800">
                A unique join code will be generated for your private group. Share this code with people you want to invite.
              </p>
            </div>
          )}
          
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-stone-300 text-[#2D2D2D] rounded-lg hover:bg-[#F5F1EB] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors"
            >
              Create Group
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
