import { useState } from 'react';
import { X } from 'lucide-react';

interface JoinGroupModalProps {
  onClose: () => void;
  onJoin: (code: string) => void;
}

export function JoinGroupModal({ onClose, onJoin }: JoinGroupModalProps) {
  const [joinCode, setJoinCode] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onJoin(joinCode.toUpperCase());
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-[#2D2D2D]">Join Private Group</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-[#9B9B9B]">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
              Join Code
            </label>
            <input
              type="text"
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              required
              className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090] uppercase font-mono text-center text-lg tracking-widest"
              placeholder="XXXXXXXX"
              maxLength={8}
            />
          </div>
          
          <div className="bg-[#F5F1EB] border border-stone-200 rounded-lg p-4">
            <p className="text-sm text-[#9B9B9B]">
              Enter the 8-character code shared by the group creator to join a private group.
            </p>
          </div>
          
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-stone-300 text-[#2D2D2D] rounded-lg hover:bg-[#F5F1EB] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors"
            >
              Join Group
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
