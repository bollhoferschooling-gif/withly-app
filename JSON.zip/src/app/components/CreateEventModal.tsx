import { useState } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';
import { Event, RSVPField, SignupSheet, SignupItem } from '../types';

interface CreateEventModalProps {
  groupId: string;
  onClose: () => void;
  onCreate: (event: Event) => void;
}

export function CreateEventModal({ groupId, onClose, onCreate }: CreateEventModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('');
  const [rsvpFields, setRsvpFields] = useState<RSVPField[]>([]);
  const [signupSheets, setSignupSheets] = useState<SignupSheet[]>([]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newEvent: Event = {
      id: `event-${Date.now()}`,
      groupId,
      title,
      description,
      date,
      time,
      location,
      rsvpFields,
      signupSheets,
      createdAt: new Date().toISOString(),
    };
    
    onCreate(newEvent);
  };
  
  const addRSVPField = () => {
    setRsvpFields([
      ...rsvpFields,
      {
        id: `field-${Date.now()}`,
        label: '',
        type: 'text',
        required: false,
      },
    ]);
  };
  
  const removeRSVPField = (id: string) => {
    setRsvpFields(rsvpFields.filter(f => f.id !== id));
  };
  
  const updateRSVPField = (id: string, updates: Partial<RSVPField>) => {
    setRsvpFields(rsvpFields.map(f => f.id === id ? { ...f, ...updates } : f));
  };

  const addOptionToField = (fieldId: string) => {
    setRsvpFields(rsvpFields.map(f => {
      if (f.id === fieldId) {
        return {
          ...f,
          options: [...(f.options || []), '']
        };
      }
      return f;
    }));
  };

  const updateFieldOption = (fieldId: string, optionIndex: number, value: string) => {
    setRsvpFields(rsvpFields.map(f => {
      if (f.id === fieldId && f.options) {
        const newOptions = [...f.options];
        newOptions[optionIndex] = value;
        return { ...f, options: newOptions };
      }
      return f;
    }));
  };

  const removeFieldOption = (fieldId: string, optionIndex: number) => {
    setRsvpFields(rsvpFields.map(f => {
      if (f.id === fieldId && f.options) {
        return {
          ...f,
          options: f.options.filter((_, i) => i !== optionIndex)
        };
      }
      return f;
    }));
  };
  
  const addSignupSheet = () => {
    setSignupSheets([
      ...signupSheets,
      {
        id: `sheet-${Date.now()}`,
        title: '',
        type: 'other',
        items: [],
      },
    ]);
  };
  
  const removeSignupSheet = (id: string) => {
    setSignupSheets(signupSheets.filter(s => s.id !== id));
  };
  
  const updateSignupSheet = (id: string, updates: Partial<SignupSheet>) => {
    setSignupSheets(signupSheets.map(s => s.id === id ? { ...s, ...updates } : s));
  };
  
  const addItemToSheet = (sheetId: string) => {
    setSignupSheets(signupSheets.map(sheet => {
      if (sheet.id === sheetId) {
        return {
          ...sheet,
          items: [
            ...sheet.items,
            {
              id: `item-${Date.now()}`,
              description: '',
              slots: 1,
              signedUp: [],
            },
          ],
        };
      }
      return sheet;
    }));
  };
  
  const removeItemFromSheet = (sheetId: string, itemId: string) => {
    setSignupSheets(signupSheets.map(sheet => {
      if (sheet.id === sheetId) {
        return {
          ...sheet,
          items: sheet.items.filter(item => item.id !== itemId),
        };
      }
      return sheet;
    }));
  };
  
  const updateSheetItem = (sheetId: string, itemId: string, updates: Partial<SignupItem>) => {
    setSignupSheets(signupSheets.map(sheet => {
      if (sheet.id === sheetId) {
        return {
          ...sheet,
          items: sheet.items.map(item => 
            item.id === itemId ? { ...item, ...updates } : item
          ),
        };
      }
      return sheet;
    }));
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-xl max-w-2xl w-full p-6 my-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-[#2D2D2D]">Create New Event</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-[#9B9B9B]">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} onKeyDown={(e) => {
          if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
          }
        }} className="space-y-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <h3 className="font-semibold text-[#2D2D2D]">Event Details</h3>
            
            <div>
              <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                Event Title *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                placeholder="e.g., Summer Picnic"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                Description *
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                rows={3}
                className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                placeholder="What's this event about?"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                  Date *
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                  Time *
                </label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  required
                  className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-[#2D2D2D] mb-2">
                Location *
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                required
                className="w-full px-4 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                placeholder="Where will this event take place?"
              />
            </div>
          </div>
          
          {/* RSVP Fields */}
          <div className="space-y-4 border-t pt-6">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-[#2D2D2D]">Custom RSVP Fields</h3>
              <button
                type="button"
                onClick={addRSVPField}
                className="flex items-center gap-2 px-3 py-1.5 text-sm bg-white text-[#2D2D2D] rounded-lg hover:bg-slate-200 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Field
              </button>
            </div>
            
            {rsvpFields.map((field, index) => (
              <div key={field.id} className="flex gap-3 p-4 bg-[#F5F1EB] rounded-lg">
                <div className="flex-1 space-y-3">
                  <input
                    type="text"
                    value={field.label}
                    onChange={(e) => updateRSVPField(field.id, { label: e.target.value })}
                    placeholder="Field label (e.g., T-Shirt Size, Dietary Restrictions)"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                  />
                  <select
                    value={field.type}
                    onChange={(e) => {
                      const newType = e.target.value as 'text' | 'number' | 'select';
                      updateRSVPField(field.id, {
                        type: newType,
                        options: newType === 'select' ? ['', ''] : undefined
                      });
                    }}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                  >
                    <option value="text">Text Input</option>
                    <option value="number">Number</option>
                    <option value="select">Multiple Choice</option>
                  </select>
                  {field.type === 'select' && (
                    <div className="space-y-2">
                      <label className="text-sm text-[#9B9B9B]">Choices:</label>
                      {(field.options || []).map((option, optionIndex) => (
                        <div key={optionIndex} className="flex gap-2">
                          <input
                            type="text"
                            placeholder={`Choice ${optionIndex + 1}`}
                            value={option}
                            onChange={(e) => updateFieldOption(field.id, optionIndex, e.target.value)}
                            className="flex-1 px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                          />
                          {field.options && field.options.length > 2 && (
                            <button
                              type="button"
                              onClick={() => removeFieldOption(field.id, optionIndex)}
                              className="text-red-500 hover:text-red-700 p-2"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      ))}
                      <button
                        type="button"
                        onClick={() => addOptionToField(field.id)}
                        className="flex items-center gap-2 px-3 py-2 text-sm bg-white border border-stone-300 text-[#7FA090] rounded-lg hover:bg-stone-50 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                        Add Choice
                      </button>
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => removeRSVPField(field.id)}
                  className="text-red-500 hover:text-red-700"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
          
          {/* Signup Sheets */}
          <div className="space-y-4 border-t pt-6">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-[#2D2D2D]">Signup Sheets</h3>
              <button
                type="button"
                onClick={addSignupSheet}
                className="flex items-center gap-2 px-3 py-1.5 text-sm bg-white text-[#2D2D2D] rounded-lg hover:bg-slate-200 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Sheet
              </button>
            </div>
            
            {signupSheets.map((sheet) => (
              <div key={sheet.id} className="p-4 bg-[#F5F1EB] rounded-lg space-y-3 border border-stone-200">
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={sheet.title}
                    onChange={(e) => updateSignupSheet(sheet.id, { title: e.target.value })}
                    placeholder="Sheet title (e.g., Potluck Items)"
                    className="flex-1 px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                  />
                  <select
                    value={sheet.type}
                    onChange={(e) => updateSignupSheet(sheet.id, { type: e.target.value as any })}
                    className="px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                  >
                    <option value="potluck">Potluck</option>
                    <option value="volunteer">Volunteer</option>
                    <option value="game">Game</option>
                    <option value="other">Other</option>
                  </select>
                  <button
                    type="button"
                    onClick={() => removeSignupSheet(sheet.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
                
                {/* Items for this sheet */}
                <div className="ml-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-medium text-[#9B9B9B]">Items</label>
                    <button
                      type="button"
                      onClick={() => addItemToSheet(sheet.id)}
                      className="flex items-center gap-1 px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                      Add Item
                    </button>
                  </div>
                  
                  {sheet.items.length === 0 ? (
                    <p className="text-xs text-slate-400 italic py-2">No items yet - add items for people to sign up for</p>
                  ) : (
                    <div className="space-y-2">
                      {sheet.items.map((item) => (
                        <div key={item.id} className="flex gap-2 items-start p-2 bg-white rounded border border-stone-200">
                          <div className="flex-1 space-y-2">
                            <input
                              type="text"
                              value={item.description}
                              onChange={(e) => updateSheetItem(sheet.id, item.id, { description: e.target.value })}
                              placeholder="Item description (e.g., Bring salad, Setup chairs)"
                              className="w-full px-2 py-1 text-sm border border-stone-300 rounded focus:outline-none focus:ring-1 focus:ring-[#7FA090]"
                            />
                            <div className="flex items-center gap-2">
                              <label className="text-xs text-[#9B9B9B]">Slots:</label>
                              <input
                                type="number"
                                min="1"
                                value={item.slots}
                                onChange={(e) => updateSheetItem(sheet.id, item.id, { slots: parseInt(e.target.value) || 1 })}
                                className="w-20 px-2 py-1 text-sm border border-stone-300 rounded focus:outline-none focus:ring-1 focus:ring-[#7FA090]"
                              />
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeItemFromSheet(sheet.id, item.id)}
                            className="text-red-400 hover:text-red-600 p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-stone-300 text-[#2D2D2D] rounded-lg hover:bg-[#F5F1EB] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors"
            >
              Create Event
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}