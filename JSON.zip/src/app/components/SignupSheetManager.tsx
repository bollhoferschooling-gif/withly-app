import { useState } from 'react';
import { Plus, Trash2, UserPlus, Clock } from 'lucide-react';
import { Event, SignupSheet, SignupItem, Group } from '../types';
import { storage } from '../utils/storage';

interface SignupSheetManagerProps {
  event: Event;
  group: Group;
  onUpdate: () => void;
}

export function SignupSheetManager({ event, group, onUpdate }: SignupSheetManagerProps) {
  const [selectedSheet, setSelectedSheet] = useState(event.signupSheets[0]?.id || '');
  const [newItemDescription, setNewItemDescription] = useState('');
  const [newItemSlots, setNewItemSlots] = useState(1);
  const [showAddItem, setShowAddItem] = useState(false);
  const [showAddSheet, setShowAddSheet] = useState(false);
  const [newSheetTitle, setNewSheetTitle] = useState('');
  const [newSheetType, setNewSheetType] = useState<'potluck' | 'volunteer' | 'game' | 'other'>('other');
  const currentUser = storage.getCurrentUser();

  // Check if current user is the group admin/creator
  const isAdmin = group ? currentUser?.id === group.creatorId : false;
  
  const currentSheet = event.signupSheets.find(s => s.id === selectedSheet);
  
  const handleAddItem = () => {
    if (!newItemDescription.trim() || !currentSheet) return;
    
    const newItem: SignupItem = {
      id: `item-${Date.now()}`,
      description: newItemDescription.trim(),
      slots: newItemSlots,
      signedUp: [],
    };
    
    const events = storage.getEvents();
    const eventIndex = events.findIndex(e => e.id === event.id);
    
    if (eventIndex >= 0) {
      const sheetIndex = events[eventIndex].signupSheets.findIndex(s => s.id === selectedSheet);
      if (sheetIndex >= 0) {
        events[eventIndex].signupSheets[sheetIndex].items.push(newItem);
        storage.saveEvents(events);
        setNewItemDescription('');
        setNewItemSlots(1);
        setShowAddItem(false);
        onUpdate();
      }
    }
  };
  
  const handleSignUp = (itemId: string) => {
    if (!currentUser || !currentSheet) return;
    
    const events = storage.getEvents();
    const eventIndex = events.findIndex(e => e.id === event.id);
    
    if (eventIndex >= 0) {
      const sheetIndex = events[eventIndex].signupSheets.findIndex(s => s.id === selectedSheet);
      if (sheetIndex >= 0) {
        const itemIndex = events[eventIndex].signupSheets[sheetIndex].items.findIndex(i => i.id === itemId);
        if (itemIndex >= 0) {
          const item = events[eventIndex].signupSheets[sheetIndex].items[itemIndex];
          
          // Check if user already signed up
          const existingSignup = item.signedUp.findIndex(s => s.userId === currentUser.id);
          
          if (existingSignup >= 0) {
            // Remove signup
            item.signedUp.splice(existingSignup, 1);
          } else {
            // Add signup
            const currentTotal = item.signedUp.reduce((sum, s) => sum + s.quantity, 0);
            if (currentTotal < item.slots) {
              item.signedUp.push({
                userId: currentUser.id,
                userName: currentUser.name,
                quantity: 1,
              });
            }
          }
          
          storage.saveEvents(events);
          onUpdate();
        }
      }
    }
  };
  
  const handleRemoveItem = (itemId: string) => {
    const events = storage.getEvents();
    const eventIndex = events.findIndex(e => e.id === event.id);

    if (eventIndex >= 0) {
      const sheetIndex = events[eventIndex].signupSheets.findIndex(s => s.id === selectedSheet);
      if (sheetIndex >= 0) {
        events[eventIndex].signupSheets[sheetIndex].items =
          events[eventIndex].signupSheets[sheetIndex].items.filter(i => i.id !== itemId);
        storage.saveEvents(events);
        onUpdate();
      }
    }
  };

  const handleAddSheet = () => {
    if (!newSheetTitle.trim()) return;

    const newSheet: SignupSheet = {
      id: `sheet-${Date.now()}`,
      title: newSheetTitle.trim(),
      type: newSheetType,
      items: [],
    };

    const events = storage.getEvents();
    const eventIndex = events.findIndex(e => e.id === event.id);

    if (eventIndex >= 0) {
      events[eventIndex].signupSheets.push(newSheet);
      storage.saveEvents(events);
      setSelectedSheet(newSheet.id);
      setNewSheetTitle('');
      setNewSheetType('other');
      setShowAddSheet(false);
      onUpdate();
    }
  };
  
  const getSheetIcon = (type: string) => {
    switch (type) {
      case 'potluck': return '🍽️';
      case 'volunteer': return '🤝';
      case 'game': return '🎮';
      default: return '📋';
    }
  };
  
  if (event.signupSheets.length === 0) {
    return (
      <div className="space-y-4">
        {isAdmin ? (
          <>
            <div className="text-center py-8 text-[#9B9B9B]">
              <p className="mb-4">No signup sheets for this event</p>
              <button
                onClick={() => setShowAddSheet(true)}
                className="px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity"
              >
                Create Signup Sheet
              </button>
            </div>

            {showAddSheet && (
              <div className="p-4 bg-[#7FA090]/10 border-2 border-[#7FA090]/30 rounded-lg space-y-3">
                <h3 className="font-semibold text-[#2D2D2D]">Create Signup Sheet</h3>
                <input
                  type="text"
                  value={newSheetTitle}
                  onChange={(e) => setNewSheetTitle(e.target.value)}
                  placeholder="Sheet title (e.g., Potluck Items, Volunteer Roles)"
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                />
                <select
                  value={newSheetType}
                  onChange={(e) => setNewSheetType(e.target.value as any)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                >
                  <option value="potluck">Potluck</option>
                  <option value="volunteer">Volunteer</option>
                  <option value="game">Game</option>
                  <option value="other">Other</option>
                </select>
                <div className="flex gap-2">
                  <button
                    onClick={handleAddSheet}
                    disabled={!newSheetTitle.trim()}
                    className="px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-opacity disabled:bg-stone-300 disabled:cursor-not-allowed"
                  >
                    Create Sheet
                  </button>
                  <button
                    onClick={() => {
                      setShowAddSheet(false);
                      setNewSheetTitle('');
                      setNewSheetType('other');
                    }}
                    className="px-4 py-2 bg-white border border-stone-300 text-[#2D2D2D] rounded-lg hover:bg-stone-50 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-8 text-[#9B9B9B]">
            <p>No signup sheets for this event</p>
          </div>
        )}
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Sheet Selector */}
      {event.signupSheets.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-2">
          {event.signupSheets.map((sheet) => (
            <button
              key={sheet.id}
              onClick={() => setSelectedSheet(sheet.id)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                selectedSheet === sheet.id
                  ? 'bg-[#7FA090] text-white'
                  : 'bg-white text-[#2D2D2D] hover:bg-slate-200'
              }`}
            >
              {getSheetIcon(sheet.type)} {sheet.title}
            </button>
          ))}
        </div>
      )}
      
      {/* Current Sheet */}
      {currentSheet && (
        <div className="space-y-4">
          {/* Signup Deadline */}
          {currentSheet.deadline && (
            <div className="flex items-center gap-2 text-sm text-orange-600 bg-orange-50 px-3 py-2 rounded-lg">
              <Clock className="w-4 h-4" />
              <span>
                Sign-up closes {new Date(currentSheet.deadline).toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  hour: 'numeric',
                  minute: '2-digit'
                })}
              </span>
            </div>
          )}
          
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-[#2D2D2D]">
              {getSheetIcon(currentSheet.type)} {currentSheet.title}
            </h3>
            {isAdmin && (
              <button
                onClick={() => setShowAddItem(!showAddItem)}
                className="flex items-center gap-2 px-3 py-1.5 text-sm bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Item
              </button>
            )}
          </div>
          
          {/* Add Item Form */}
          {showAddItem && (
            <div className="p-4 bg-[#7FA090]/10 border border-[#7FA090]/30 rounded-lg space-y-3">
              <input
                type="text"
                value={newItemDescription}
                onChange={(e) => setNewItemDescription(e.target.value)}
                placeholder="Item description (e.g., Bring salad, Setup tables)"
                className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
              />
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="block text-xs text-[#9B9B9B] mb-1">Available Slots</label>
                  <input
                    type="number"
                    min="1"
                    value={newItemSlots}
                    onChange={(e) => setNewItemSlots(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#7FA090]"
                  />
                </div>
                <div className="flex items-end gap-2">
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="px-4 py-2 bg-[#7FA090] text-white rounded-lg hover:opacity-90 transition-colors"
                  >
                    Add
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddItem(false);
                      setNewItemDescription('');
                      setNewItemSlots(1);
                    }}
                    className="px-4 py-2 bg-slate-200 text-[#2D2D2D] rounded-lg hover:bg-slate-300 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Items List */}
          <div className="space-y-3">
            {currentSheet.items.length === 0 ? (
              <div className="text-center py-8 text-[#9B9B9B]">
                <p className="text-sm">No items yet</p>
                <p className="text-xs">Add items for people to sign up for</p>
              </div>
            ) : (
              currentSheet.items.map((item) => {
                const currentTotal = item.signedUp.reduce((sum, s) => sum + s.quantity, 0);
                const userSignedUp = item.signedUp.find(s => s.userId === currentUser?.id);
                const isFull = currentTotal >= item.slots;
                
                return (
                  <div
                    key={item.id}
                    className="p-4 border border-stone-200 rounded-lg hover:border-stone-300 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="font-medium text-[#2D2D2D] mb-2">
                          {item.description}
                        </h4>
                        
                        {/* Progress Bar */}
                        <div className="mb-2">
                          <div className="h-2 bg-white rounded-full overflow-hidden">
                            <div 
                              className={`h-full transition-all ${isFull ? 'bg-red-500' : 'bg-[#7FA090]/100'}`}
                              style={{ width: `${Math.min((currentTotal / item.slots) * 100, 100)}%` }}
                            ></div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <span className={`text-sm font-medium ${isFull ? 'text-red-600' : 'text-[#9B9B9B]'}`}>
                            {currentTotal} of {item.slots} claimed
                          </span>
                          {isFull && (
                            <span className="text-xs px-2 py-0.5 bg-red-100 text-red-700 rounded font-medium">
                              Full
                            </span>
                          )}
                        </div>
                      </div>
                      {isAdmin && (
                        <button
                          onClick={() => handleRemoveItem(item.id)}
                          className="text-slate-400 hover:text-red-600 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    
                    {/* Signed Up Users */}
                    {item.signedUp.length > 0 && (
                      <div className="mb-3 space-y-1">
                        {item.signedUp.map((signup) => (
                          <div
                            key={signup.userId}
                            className="text-sm text-[#9B9B9B] flex items-center gap-2"
                          >
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            {signup.userName}
                            {signup.quantity > 1 && ` (×${signup.quantity})`}
                          </div>
                        ))}
                      </div>
                    )}
                    
                    {/* Sign Up Button */}
                    <button
                      onClick={() => handleSignUp(item.id)}
                      disabled={!userSignedUp && isFull}
                      className={`w-full px-4 py-2 rounded-lg transition-colors flex items-center justify-center gap-2 ${
                        userSignedUp
                          ? 'bg-red-100 text-red-700 hover:bg-red-200'
                          : isFull
                          ? 'bg-white text-slate-400 cursor-not-allowed'
                          : 'bg-green-100 text-green-700 hover:bg-green-200'
                      }`}
                    >
                      {userSignedUp ? (
                        <>
                          <Trash2 className="w-4 h-4" />
                          Remove My Sign-Up
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-4 h-4" />
                          {isFull ? 'Full' : 'Sign Me Up'}
                        </>
                      )}
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}